from pathlib import Path
import json,gzip,hashlib,statistics,datetime,subprocess
p=Path('.tint-bootstrap/perf');out=Path('docs/results');stem='native-generated-code-integration-v2';assets=out/(stem+'-assets');assets.mkdir(exist_ok=True)
def read(n):return json.loads((p/n).read_text())
cohorts=[read(n+'/result.json')for n in ['integrated-perf-selfbuild-v3','integrated-perf-selfbuild-reverse-v1']];rows=[x for c in cohorts for x in c['observations']]
assert len(rows)==4 and all(x['initial']['state']=='stopped'and x['final']['state']=='exited'and x['final']['exitStatus']==0 and x['identicalToAfterStage1']for x in rows)
assert len(set(x['outputSha256']for x in rows))==1
summaries={}
for label in ['before','after']:
 a=[x for x in rows if x['label']==label];summaries[label]={k:{'median':statistics.median(v),'min':min(v),'max':max(v)}for k,v in {'cpuMs':[x['cpu']['cpuMsLowerBound']for x in a],'wallMs':[x['inferiorWallMs']for x in a],'instructions':[x['cpu']['lastCPU']['instructions']for x in a],'cycles':[x['cpu']['lastCPU']['cycles']for x in a]}.items()}
current=read('integrated-final-selfbuild-v79/result.json');assert current['afterStageImageIdentical']and current['signatureExit']==0 and current['dwarfExit']==0 and current['observations'][0]['final']['exitStatus']==0
fixture=read('final-base-string-fixture-v79-native.json');assert len(fixture['observations'])==8 and all(x['initial']['state']=='stopped'and x['final']['state']=='exited'and x['final']['exitStatus']==42 for x in fixture['observations'])
gate=read('integrated-final-gate-v3-exit.json');assert gate['status']==0
log=(p/'integrated-final-gate-v3.log').read_text();import re;tests=int(re.findall(r'ℹ tests ([0-9]+)',log)[-1]);assert '[tint-check] all gates passed'in log
base=json.load(open(out/'native-generated-code-integration-v1.json'));m=read('integrated-final-v79-manifest.json')
files=[]
for pat in ['integrated-perf-selfbuild-reverse-v1*','integrated-current-*','final-current-string-fixture-v78*','integrated-perf-gate-v2*','integrated-final-*','final-base-string-fixture-v79*']:
 for f in p.glob(pat):
  if'toolchain'in f.name:continue
  if f.is_file():files.append(f)
  elif f.is_dir():files.extend(x for x in f.rglob('*')if x.is_file())
files.extend(p/'integrated-final-toolchain-v79'/n for n in ['toolchain.json','source-snapshot.json'])
files.append(p/'codegen-ordered-inline-control-toolchain-v65/tools/perf-conservative-ordered-inline.mjs')
files.extend(p/n for n in ['retain-integrated-perf-v2.py','freeze-integrated-final-v79.mjs','time-cpu-counters-v1.ts','observe-selfbuild-cpu-v2.py','p_capture_report_v1.py'])
index=[]
for f in sorted(set(files)):
 if f.suffix not in ['.json','.jsonl','.ts','.js','.mjs','.py','.txt','.log']:continue
 b=f.read_bytes();dst=assets/(str(f.resolve().relative_to(p.resolve())).replace('/','--')+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));index.append({'source':str(f),'asset':str(dst),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r={'kind':'native-generated-code-two-order-integration','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'supersedesPendingAssessment':'native-generated-code-integration-v1.json','scope':'Both generated-code slices; same pinned source cohort in both native execution orders, plus final correctness-only selfbuild after rebase on the agreed 29f28570 base, including J RegExp and H Temporal changes. No cross-source performance ratio.','cohorts':cohorts,'summary':summaries,'canonical':base['canonical'],'canonicalCPU':base['canonicalCPU'],'canonicalEvidence':'native-generated-code-integration-v1.json','supplementaryRetention':'Includes the exact original reference control65 load adapter, whose hash and generated source were recorded in the earlier report; that adapter file is also retained directly here.','currentRebase':m,'agreedValidationBase':'29f28570ad7f484c172c80426f4ec539e78aad8d','lastCodeChange':'22ca7b65','currentSelfbuild':current,'currentStringFixture':fixture,'currentFixtureBuild':read('final-base-string-fixture-v79-build.json'),'gate':gate,'gateTests':tests,'interpretation':'One combined native compiler pair regresses, one improves. Two-order medians show a modest CPU/cycle benefit with wide candidate CPU spread. Component four-pair benchmarks are stronger evidence; single canonical eval-heavy pairs remain mixed. No whole-suite speedup is claimed.','assets':index}
(out/(stem+'.json')).write_text(json.dumps(r,indent=2)+'\n')
a,b=summaries['before'],summaries['after'];c=current['observations'][0]
(out/(stem+'.md')).write_text(f'''# Two-order generated-code integration

The reverse-order compiler pair resolves the pending first-pair assessment in
[v1](native-generated-code-integration-v1.md). **The first pair regresses; the
second improves.** Across the two execution orders:

| Same-source native compiler | Before median (range) | After median (range) |
| --- | ---: | ---: |
| Inferior CPU seconds | {a['cpuMs']['median']/1000:.3f} ({a['cpuMs']['min']/1000:.3f}–{a['cpuMs']['max']/1000:.3f}) | {b['cpuMs']['median']/1000:.3f} ({b['cpuMs']['min']/1000:.3f}–{b['cpuMs']['max']/1000:.3f}) |
| Inferior wall seconds | {a['wallMs']['median']/1000:.3f} | {b['wallMs']['median']/1000:.3f} |
| Retired instructions | {a['instructions']['median']:,.0f} | {b['instructions']['median']:,.0f} |
| Cycles | {a['cycles']['median']:,.0f} | {b['cycles']['median']:,.0f} |

CPU median ratio is {a['cpuMs']['median']/b['cpuMs']['median']:.3f}x; cycles fall
{100*(1-b['cycles']['median']/a['cycles']['median']):.3f}% and instructions fall
{100*(1-b['instructions']['median']/a['instructions']['median']):.3f}%.
There are only two compiler executions per representation, and candidate CPU
spread is wide. Four-pair [list](native-reference-inlining-throughput-v1.md)
and [UTF-16 operation](native-string-word-kernels-throughput-v1.md) benchmarks
provide independent instruction/cycle evidence. No broad eval-preparation or
whole-suite speedup is claimed: the canonical CPU pairs remain mixed.

Both canonical source-pinned selections pass **9/9**, with zero failures,
unsupported cases, timeouts, crashes or harness errors. Unchanged sources,
harnesses, strictness/goals, fresh processes, resources, 300 s containment and
journals are retained in [v1](native-generated-code-integration-v1.json), including
all three heavy-variant CPU/load observations. Their portable snapshot is pinned
to the performance cohort; it is not relabeled as the later RegExp source.
All four native compiler executions produce the identical 53,762,178-byte image,
SHA-256 `60df7c66ba75cf62e2c18df308c8ab0811b8fd34002c0fbfd46c4061278f6c3e`,
equal to candidate stage 1. Signature/DWARF checks pass.

After main's RegExp and Temporal changes, a new rebuilt frozen **correctness-only** cohort uses
main `{m['mainCommit']}` plus this stack, source `{m['sourceSnapshot']['sha256']}`.
Its native compiler exits 0 and reproduces stage 1, {c['outputBytes']:,} bytes,
SHA-256 `{c['outputSha256']}`. Eight new boundary/surrogate/copy/GC fixture
inferiors stop initially and exit 42. No cross-source timing comparison is made.
The fresh `tint-check` passes **{tests:,} tests**, types, boundaries and formatting.

[Raw evidence]({stem}.json) retains every repetition, load, missing-CPU bound,
control identity, current-source selfbuild, fixture, gate and hash-indexed assets.
The initial stale-built-baseline failure and missing-manifest preflight remain
in v1, with no native execution credited. The [native hot-function table](native-hot-functions-v15.md)
separates expected algorithmic work from emitted per-operation overhead.
Node-hosted batch compiles are a separate path; selected native gains do not
justify revising the earlier whole-suite compilation-only hour projection.
''')
print({'report':stem,'assets':len(index),'gateTests':tests})
