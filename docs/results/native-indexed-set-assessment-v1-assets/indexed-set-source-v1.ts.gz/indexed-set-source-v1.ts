import {createSet,addSet,hasSet,deleteSet,clearSet,sizeSet,cloneSet,createSetCursor,advanceSetCursor,readSetCursor} from "@tint/foundation/collections/linked-set";
export function run():number {
 const set=createSet<string>();for(let i=0;i<96;i++)addSet<string>(set,"key-"+i);
 addSet<string>(set,"Aa");addSet<string>(set,"BB");if(sizeSet<string>(set)!==98||!hasSet<string>(set,"Aa")||!hasSet<string>(set,"BB"))return 1;
 const cursor=createSetCursor<string>(set);if(!advanceSetCursor<string>(cursor)||readSetCursor<string>(cursor)!=="key-0")return 2;
 deleteSet<string>(set,"key-0");deleteSet<string>(set,"key-1");addSet<string>(set,"key-0");if(!advanceSetCursor<string>(cursor)||readSetCursor<string>(cursor)!=="key-2")return 3;
 const copy=cloneSet<string>(set),held=createSetCursor<string>(set);advanceSetCursor<string>(held);clearSet<string>(set);addSet<string>(set,"later");if(!advanceSetCursor<string>(held)||readSetCursor<string>(held)!=="later")return 4;
 const numbers=new Set<number>();for(let i=0;i<32;i++)numbers.add(i);numbers.add(NaN);numbers.add(-0);if(numbers.size!==33||!numbers.has(NaN)||!numbers.has(0))return 5;numbers.delete(NaN);numbers.add(NaN);
 const first={value:1},second={value:1},objects=createSet<{value:number}>();addSet<{value:number}>(objects,first);addSet<{value:number}>(objects,second);for(let i=0;i<24;i++)addSet<{value:number}>(objects,{value:i});if(!hasSet<{value:number}>(objects,first)||hasSet<{value:number}>(objects,{value:1}))return 6;
 for(let i=0;i<2000;i++){const scratch=new Uint32Array(64);scratch[0]=i;}
 if(sizeSet<string>(copy)!==97||!hasSet<string>(copy,"key-0")||hasSet<string>(copy,"key-1")||!hasSet<string>(copy,"Aa")||!hasSet<string>(copy,"BB"))return 7;
 if(!hasSet<{value:number}>(objects,first)||!numbers.has(NaN)||!numbers.has(31))return 8;
 return 42;
}