import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// Real managed heap exhaustion inside user JavaScript: handlers must never run.
const fill = `var a = []; for (;;) a.push("x".repeat(1048576) + a.length);`;
const sources = [
  `var ran = 0; try { ${fill} } catch (e) { ran = 1; } throw new Error("catch handler ran " + ran);`,
  `var seen = "none"; Promise.resolve().then(function () { ${fill} }).then(undefined, function (e) { seen = typeof e; throw new Error("rejection handler saw " + seen); });`,
  `var seen = "none"; try { throw "MANAGED_HEAP_EXHAUSTED"; } catch (e) { seen = e; } if (seen !== "MANAGED_HEAP_EXHAUSTED") throw new Error("ordinary string not caught: " + seen);`,
];
const cases = sources.map((source) => { const plan = executionPlan(source, "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(process.argv[2]!, built.bytes); chmodSync(process.argv[2]!, 0o755);
console.error(new Date().toISOString(), "wrote", process.argv[2], built.bytes.length);
