import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const frozen=JSON.parse(readFileSync(process.argv[4]??'.tint-bootstrap/c1-phase2-toolchain-v1.json','utf8'));
const events=readFileSync('/Users/stephenbelanger/.t3/tint-briefs/load-events.md','utf8');assert.ok(events.lastIndexOf('HOST AUTHORIZATION RESTORED')>events.lastIndexOf('HOST AUTHORIZATION STALL'),'host authorization is not restored');assert.equal(process.argv[2],'30');assert.equal(process.argv[3],'31');assert.equal(process.argv[5],'2');assert.equal(frozen.runIdentity,'9f1a545977a5d67405fe168b0386aca83751359ef9def3e6e77d508c02113b76');const prefix=readFileSync('docs/results/test262-c1-breadth-language-expressions-class-direct-files-v1.jsonl');assert.equal(createHash('sha256').update(prefix).digest('hex'),'5a7f1aa0b15276858c2a10eb28a08d1c45f6a03e09267dbe54f8e28364e532c3');const pausePath=process.cwd()+'/.tint-bootstrap/c1-expression-root-v2.pause';assert.ok(!existsSync(pausePath)&&!existsSync(pausePath+'.ack'));writeFileSync('docs/results/test262-c1-breadth-language-expressions-class-direct-files-v2.jsonl',prefix,{flag:'wx'});
const queue=JSON.parse(readFileSync('docs/results/c1-complete-scope-census-node-v1.json','utf8')).populations;
const from=Number(process.argv[2]??0),end=Number(process.argv[3]??queue.length);
const node='/Users/stephenbelanger/.nvm/versions/node/v24.12.0/bin/node',slot='/Users/stephenbelanger/.t3/tint-slots/slot',suite='/Users/stephenbelanger/Code/nodejs/tint/.tint-bootstrap/test262';
const completed=[];function log(...s){console.log(new Date().toISOString(),...s);}
for(let i=from;i<end;i++){
 const item=queue[i],label=item.selection.replaceAll('*.js','direct-files').replaceAll('/','-'),report=`docs/results/test262-c1-breadth-${label}-v${process.argv[5]??1}.json`,journal=report+'l',stderr=report+'.stderr.txt';
 assert.ok(existsSync(journal));const out=openSync(report,'wx'),err=openSync(stderr,'wx');
 const env={...process.env,TINT_TEST262_SOURCES:frozen.toolchain.sources,TINT_TEST262_JOURNAL:process.cwd()+'/'+journal,TINT_TEST262_MODULES:'1',TINT_TEST262_DEBUGGER_LAUNCH:'debugserver-direct',TINT_TEST262_CONTAINMENT_MS:'300000',TINT_TEST262_HEARTBEAT_MS:'30000',TINT_TEST262_STALL_MS:'150000'};
 env.TINT_TEST262_PAUSE=pausePath;env.TINT_TEST262_RESUME='1';env.TINT_TEST262_DEBUGGER_TRACE='0';delete env.TINT_TEST262_CAPTURE_SOURCES;delete env.TINT_TEST262_VARIANTS;
 const slotText=readFileSync(slot,'utf8'),slotSource=report+'.slot-source.txt',slotSourceSha256=createHash('sha256').update(slotText).digest('hex');
 writeFileSync(slotSource,slotText,{flag:'wx'});
 const child=spawn('/bin/zsh',['-c',slotText,slot,'runner','6','--',node,frozen.toolchain.entry,suite,item.selection,'64'],{env,stdio:['ignore',out,err]});closeSync(out);closeSync(err);
 log(`selection ${i+1}/${queue.length} ${item.selection}; slotPid=${child.pid}; journal=${journal}; stderr=${stderr}`);
 const timer=setInterval(()=>{const lines=readFileSync(stderr,'utf8').trim().split('\n');log(`progress ${item.selection}:`,lines.slice(-2).join(' | '));},30000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});clearInterval(timer);
 let result;try{result=JSON.parse(readFileSync(report,'utf8'));}catch(error){log('invalid/incomplete report',JSON.stringify(code),String(error));process.exitCode=1;break;}
 const last=JSON.parse(readFileSync(journal,'utf8').trim().split('\n').at(-1));
 const accepted=code.code===0&&last.kind==='complete'&&result.totals.total===item.variants&&result.totals.passed===item.variants;
 log('finished',item.selection,JSON.stringify(code),JSON.stringify(result.totals));completed.push({selection:item.selection,report,journal,stderr,slotSource,slotSourceSha256,exit:code,totals:result.totals});
 writeFileSync('.tint-bootstrap/c1-expression-root-resume-v2-progress.json',JSON.stringify({completed,stoppedForTriage:!accepted,nextIndex:i+1},null,2)+'\n');
 if(!accepted){log('stopped for triage; no subsequent selection launched');process.exitCode=1;break;}
}
