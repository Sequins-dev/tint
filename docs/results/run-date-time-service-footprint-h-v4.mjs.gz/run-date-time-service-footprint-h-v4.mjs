import{spawn}from'node:child_process';
import{openSync,writeFileSync,readFileSync}from'node:fs';
import{resolve}from'node:path';
const root=resolve('.'),driver=resolve('.tint-bootstrap/measure-dtf-runtime-footprint-h-v4.mjs');
const main=resolve('.tint-bootstrap/ready-calendar-h/.tint-bootstrap/node-toolchain-dtf-main-control-h-v116'),unit=resolve('.tint-bootstrap/node-toolchain-temporal-h-v115');
const jobs=[['main','small',main,'monolithic'],['unit','small',unit,'aot'],['main','batch64',main,'monolithic'],['unit','batch64',unit,'aot']];
for(const[label,size,frozen,mode]of jobs){
 const tag='dtf-service-footprint-'+label+'-'+size+'-h-v4',report=root+'/.tint-bootstrap/'+tag+'.json',manifest=resolve('docs/results/dtf-footprint-'+size+'-variants-h-v1.json');
 const out=openSync('.tint-bootstrap/'+tag+'.stdout','wx'),err=openSync('.tint-bootstrap/'+tag+'.log','wx');
 const child=spawn('/Users/stephenbelanger/.t3/tint-slots/slot',['runner','10','--',process.execPath,driver,frozen,manifest,label+'-'+size,report],{stdio:['ignore',out,err],env:{...process.env,TINT_TEST262_NATIVE_SERVICES:mode,TINT_NATIVE_SERVICE_CACHE:resolve('.tint-bootstrap/native-service-cache'),TINT_TEST262_DEBUGGER_LAUNCH:'debugserver-direct',TINT_TEST262_HEARTBEAT_MS:'30000',TINT_TEST262_STALL_MS:'150000'}});
 console.log(new Date().toISOString(),tag,'wrapper='+child.pid);const beat=setInterval(()=>console.log(new Date().toISOString(),tag,'wrapper='+child.pid),30000);
 const result=await new Promise((done,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>done({code,signal}));});clearInterval(beat);writeFileSync('.tint-bootstrap/'+tag+'.exit',JSON.stringify(result)+'\n',{flag:'wx'});
 if(result.code!==0)throw Error(tag+' '+JSON.stringify(result));const measured=JSON.parse(readFileSync(report));if(measured.variants!==(size==='small'?2:64))throw Error('denominator mismatch');if(mode==='aot'&&!measured.servicePreparation?.nativeServiceUnitIndexSha256)throw Error('service unit missing');console.log(JSON.stringify({tag,compileCpuMs:measured.compileCpuMs,imageBytes:measured.imageBytes,peakRssBytes:measured.peakRssBytes,service:measured.servicePreparation}));
}
