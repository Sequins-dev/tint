import{execFileSync}from'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {test262Checkout,test262Source} from '../tools/test262-checkout.ts';
import {testMetadata,syntaxVariants} from '../tools/test262.ts';
import {executionPlan} from '../tools/test262-execution.ts';
import {readJournal,aggregateEvidence,canonicalTable} from '../tools/test262-coverage-ledger.ts';
const checkout='.tint-bootstrap/test262',roots=['language/statements/variable','language/statements/let','language/statements/const','language/function-code'],expected=new Map(),harnessHashes=new Map();
for(const selection of roots){const suite=test262Checkout(checkout,selection);if(suite.dirty||suite.revision!=='91c70759363c46557b694792bf34a2551a7af5ba')throw Error('pinned checkout mismatch');for(const file of suite.files){const {source,sha256}=test262Source(file.filename),metadata=testMetadata(source);for(const variant of syntaxVariants(metadata)){const plan=executionPlan(source,variant,metadata),harness=plan.harness.map(name=>{if(!harnessHashes.has(name))harnessHashes.set(name,test262Source(resolve(checkout,'harness',name)).sha256);return{name,sha256:harnessHashes.get(name)};});expected.set(file.path+'\0'+variant,{path:file.path,sha256,variant,metadata,harness,canSuspend:plan.canSuspend});}}}
const base=JSON.parse(readFileSync('docs/results/test262-coverage-ledger-v18.json')),reports=[],excludedAncestors=[];
for(const record of base.reports){const selection=record.rootSelection??record.selection,descendant=roots.some(x=>selection===x||selection.startsWith(x+'/')),ancestor=roots.some(x=>x.startsWith(selection+'/'));if(!descendant&&!ancestor)continue;const data=record.file.endsWith('.jsonl')?await readJournal(record.file):JSON.parse(readFileSync(record.file));if(ancestor&&!data.observations.some(x=>expected.has(x.path+'\0'+x.variant))){excludedAncestors.push({file:record.file,reason:'No observations in the assigned four-family scope.'});continue;}if(ancestor)throw Error('overlapping parent evidence requires full parent validation '+record.file);reports.push({...data,...record,totals:data.totals,observations:data.observations});}

for(const file of process.argv.slice(2)){
 const report=JSON.parse(readFileSync(file));
 if(report.revision!=='91c70759363c46557b694792bf34a2551a7af5ba'||report.dirty!==false)throw Error('invalid report '+file);
 let dateFile=file,dateSource='first Git addition commit (run date unavailable)';
 if(report.provenance?.journal){
  const journalFile=report.provenance.journal,bytes=readFileSync(journalFile);
  if(!journalFile.startsWith('docs/results/')||createHash('sha256').update(bytes).digest('hex')!==report.provenance.journalSha256||bytes.length!==report.provenance.journalBytes)throw Error('extracted journal identity differs');
  await readJournal(journalFile);dateFile=journalFile;dateSource='linked journal first Git addition commit (run date unavailable)';
 }else{
  const journal=await readJournal(file.replace(/\.json$/,'.jsonl'));if(!journal.complete)throw Error('incomplete direct native report '+file);
 }
 const date=execFileSync('git',['log','--diff-filter=A','--format=%cI','--',dateFile],{encoding:'utf8'}).trim().split('\n').at(-1);if(!date)throw Error('commit evidence before audit');
 reports.push({...report,file,date,dateSource});
}
const result=aggregateEvidence(expected,reports);if(result.rejected.length)throw Error(JSON.stringify(result.rejected));
const totals={};for(const row of result.ledger)totals[row.status]=(totals[row.status]??0)+1;
const families=roots.map(selection=>{const rows=result.ledger.filter(x=>x.path.startsWith(selection+'/')),statuses={};for(const row of rows)statuses[row.status]=(statuses[row.status]??0)+1;return{selection,total:rows.length,statuses};});
const sha=file=>createHash('sha256').update(readFileSync(file)).digest('hex'),nativeInputReports=result.accepted.map(r=>({file:r.file,sha256:sha(r.file),date:r.date,dateSource:r.dateSource,selection:r.selection,rootSelection:r.rootSelection,requestedVariants:r.requestedVariants,sourceSnapshot:r.sourceSnapshot,frozenToolchainSha256:r.frozenToolchainSha256})),table=canonicalTable(result.ledger);
const proof={kind:'language-declarations-and-function-code-native-scope-audit',conformance:false,time:new Date().toISOString(),inputHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),pinnedRevision:'91c70759363c46557b694792bf34a2551a7af5ba',scope:roots,baselineLedger:'test262-coverage-ledger-v18.json',baselineLedgerSha256:sha('docs/results/test262-coverage-ledger-v18.json'),expectedVariants:expected.size,totals,complete:totals.pass===1148,acceptedReports:result.accepted.length,rejected:result.rejected,excludedAncestors,families,nativeInputReports,canonicalVariantTableSha256:table.sha256,syntaxNegativeVariants:result.ledger.filter(x=>x.syntaxNegative).length,runtimeVariants:result.ledger.filter(x=>!x.syntaxNegative).length,policy:'Latest valid complete native observation per pinned variant; unchanged source and ordered harness metadata validated. No live prefix or Node result counts.'};
console.log(JSON.stringify(proof,null,2));
