import {verifyHostedFixture} from '../../tools/hosted-fixture.ts';
verifyHostedFixture(`
import {createSourceTextView} from "source";
import {parseScript,parseModule,rewriteModule,type Expression} from "syntax";
import {lowerScript} from "lowering";
import {checkClosureModule} from "checker";
export function run():number{
 const parsed=parseScript(createSourceTextView("function d(v,c){} @d class C{@d accessor x=1;@d m(){} @d static y=2;}"));
 if(!parsed.ok)return 1;
 const lowered=lowerScript(parsed.value);if(!lowered.ok)return 2;
 const count={value:0};rewriteModule(lowered.value,{expression:(node:Expression,_original:Expression):Expression=>{if(node.kind==="call"){const callee=node.callee;if(callee.kind==="identifier"&&(callee.name==="decorateClass"||callee.name==="decorateClassElement"))count.value++;}return node;}});
 if(count.value!==4)return 3;
 const typed=parseModule(createSourceTextView("function d(v:number):void{} @d class C{}"));if(!typed.ok)return 4;
 const checked=checkClosureModule(typed.value);if(checked.ok)return 5;
 if(checked.error.code!=="UNSUPPORTED"||!checked.error.message.includes("typed decorators"))return 6;
 return 42;
}
`,'class-decorator-compiler',[
 ['source','packages/source/src/text.ts'],['syntax','packages/typescript/src/syntax/index.ts'],['lowering','packages/js-engine/src/lowering/index.ts'],['checker','packages/typescript/src/checker/index.ts']
]);
