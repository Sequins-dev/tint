import subprocess,time,pathlib,sys,os,json,re,hashlib
frozen,selection,name=sys.argv[1:4];batch=sys.argv[4] if len(sys.argv)>4 else "64";root=pathlib.Path.cwd();folder=root/'.tint-bootstrap/c2';journal=folder/(name+'.jsonl');canonical=root/'docs/results'/(name+'.json');out=folder/(name+'.report.partial');err=folder/(name+'.stderr');start=time.time()
env=os.environ.copy();env.update(TINT_TEST262_DEBUGGER_LAUNCH='debugserver-direct',TINT_TEST262_SOURCES=str(folder/frozen/'source-snapshot.json'),TINT_TEST262_JOURNAL=str(journal),TINT_TEST262_MODULES='1',TINT_TEST262_HEARTBEAT_MS='30000',TINT_TEST262_STALL_MS='150000',TINT_TEST262_CONTAINMENT_MS='300000')
cmd=['/Users/stephenbelanger/.t3/tint-slots/slot','runner','8','--','/Users/stephenbelanger/.nvm/versions/node/v24.12.0/bin/node',str(folder/frozen/'tools/test262-native-run.ts'),'/Users/stephenbelanger/Code/nodejs/tint/.tint-bootstrap/test262',selection,batch]
with out.open('x') as stdout,err.open('x') as stderr:
 p=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr);print('START',p.pid,selection,'journal',journal,flush=True)
 while p.poll() is None:
  rows=[r.split(None,5) for r in subprocess.check_output(['ps','-axo','pid,ppid,etime,time,%cpu,command'],text=True).splitlines()[1:]];ids={p.pid}
  for _ in range(5):ids.update(int(r[0]) for r in rows if int(r[1]) in ids)
  print('CPU/WALL',[(r[0],r[2],r[3],r[4],r[5][:95]) for r in rows if int(r[0]) in ids],flush=True)
  print('PROGRESS elapsed',round(time.time()-start),'journal bytes',journal.stat().st_size if journal.exists() else 0,'stderr',err.read_text()[-700:],flush=True);time.sleep(25)
 print('EXIT',p.returncode,flush=True);(folder/(name+'.exit')).write_text(str(p.returncode))
 if p.returncode==0:
  raw=out.read_text();report=json.loads(raw)
  first=re.search(r'^(\d{4}-\d{2}-\d{2}T[^ ]+Z) \[Test262\]',err.read_text(),re.M)
  if first is None:raise RuntimeError('missing actual runner first-heartbeat timestamp')
  report.setdefault('startedAt',first.group(1))
  report['observationTiming']={'source':'first runner heartbeat','stderr':str(err),'stdout':str(out),'stdoutSha256':hashlib.sha256(raw.encode()).hexdigest(),'policy':'Publication preserves run age; later focused rechecks remain later evidence.'}
  with canonical.open('x') as final:final.write(json.dumps(report,indent=2)+'\n')
  print('TOTALS',report['totals'],flush=True)
 sys.exit(p.returncode)
