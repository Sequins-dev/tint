import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {NativeImageRunner,nativeDebuggerLaunch} from './frozen-v28/tools/test262-native-process.ts';
import {startNativeHeartbeat} from './frozen-v28/tools/test262-native-heartbeat.ts';
const descriptor='docs/results/c2-frozen-toolchain-v28-decorators-v1.json',frozen=JSON.parse(fs.readFileSync(descriptor));
const metadata=fs.readFileSync('.tint-bootstrap/c2/decorator-native-build-v5.log','utf8').split('\n').filter(l=>l.startsWith('{"path"')).map(JSON.parse).at(-1);
assert.ok(metadata);const manifest=JSON.parse(fs.readFileSync(metadata.manifest));
assert.deepEqual(manifest.sourceSnapshot,frozen.sourceSnapshot);assert.equal(nativeDebuggerLaunch,'debugserver-direct');
const bytes=fs.readFileSync(metadata.path);assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),manifest.imageSha256);
const heartbeat=startNativeHeartbeat('C2 decorator native semantic fixture');
const image=new NativeImageRunner(bytes,300000),report={kind:'native-class-decorator-regression',conformance:false,startedAt:new Date().toISOString(),toolchain:descriptor,buildManifest:manifest,debuggerLaunch:nativeDebuggerLaunch,assertions:'NativeImageRunner requires an initial stopped LLDB process and the expected exit42 for each case; no retries.',cases:[],complete:false};
try{for(let index=0;index<manifest.cases.length;index++){heartbeat.phase('executing semantic case '+index);const began=performance.now(),outcome=image.run(index);report.cases.push({index,outcome,elapsedMs:performance.now()-began});console.log('CASE',index,JSON.stringify(outcome));assert.equal(outcome.kind,'completed');}report.complete=true;}catch(e){report.failure=String(e);process.exitCode=1;}finally{image.close();report.completedAt=new Date().toISOString();report.driverSha256=crypto.createHash('sha256').update(fs.readFileSync(import.meta.filename)).digest('hex');fs.writeFileSync('docs/results/c2-class-decorator-native-v1.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});await heartbeat.close();console.log('COMPLETE',report.complete);}
