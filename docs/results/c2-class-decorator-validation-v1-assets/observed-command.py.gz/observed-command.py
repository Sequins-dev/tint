import subprocess,time,pathlib,sys
log=pathlib.Path(sys.argv[1]);started=time.time()
with log.open('x') as f:
 p=subprocess.Popen(sys.argv[2:],stdout=f,stderr=subprocess.STDOUT)
 while p.poll() is None:
  rows=[r.split(None,5) for r in subprocess.check_output(['ps','-axo','pid,ppid,etime,time,%cpu,command'],text=True).splitlines()[1:]]
  ids={p.pid}
  for _ in range(5):
   ids.update(int(r[0]) for r in rows if int(r[1]) in ids)
  print('CPU/WALL',[(r[0],r[2],r[3],r[4],r[5][:80]) for r in rows if int(r[0]) in ids],flush=True)
  print('PROGRESS',p.pid,'elapsed',round(time.time()-started),'bytes',log.stat().st_size,'tail',log.read_text()[-180:],flush=True);time.sleep(25)
 print('EXIT',p.returncode,flush=True);log.with_suffix('.exit').write_text(str(p.returncode));sys.exit(p.returncode)
