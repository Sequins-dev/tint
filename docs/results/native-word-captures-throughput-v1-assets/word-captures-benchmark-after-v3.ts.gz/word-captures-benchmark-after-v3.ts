import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-word-captures-toolchain-v36/tools/hosted-fixture.ts";

verifyHostedFixture(
  `type Box={value:number};function hold(value:Box,bytes:Uint32Array,text:string,callback:()=>number,flag:boolean):()=>number{return ()=>value.value+(bytes[0]??0)+callback()+(flag?1:0)+(text==="capture-42"?1:1000);}export function run():number{const value:Box={value:10},bytes=new Uint32Array(2),context:Box={value:10};bytes[0]=20;const callback:()=>number=()=>context.value,text="capture-"+42;for(let i=0;i<5000000;i++){const read=hold(value,bytes,text,callback,true);if(read()!==42)return 1;}return 42;}`,
  "word-captures-allocation",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 524288,
    allocationCapacity: 32768,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
