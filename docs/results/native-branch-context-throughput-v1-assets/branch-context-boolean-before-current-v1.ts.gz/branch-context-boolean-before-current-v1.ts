import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/branch-context-current-main-toolchain-v84/tools/hosted-fixture.ts";
verifyHostedFixture(
  `function branch(a:boolean,b:boolean,c:boolean):number{if(a&&(b||!c))return 1;return 0;}export function run():number{let count=0;for(let i=0;i<16777216;i++)count+=branch((i&1)!==0,(i&2)!==0,(i&4)!==0);return count===6291456?42:1;}`,
  "branch-context",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 4194304,
    allocationCapacity: 131072,
    rootCapacity: 8192,
    stackBytes: 1048576,
  },
);
