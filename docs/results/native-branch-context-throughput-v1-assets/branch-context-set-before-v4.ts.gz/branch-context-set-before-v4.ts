import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/branch-context-main-toolchain-v80/tools/hosted-fixture.ts";
verifyHostedFixture(
  `interface Entry{value:string;next:Entry|undefined;}function has(head:Entry|undefined,value:string):boolean{let entry=head;while(entry!==undefined){if(entry.value===value||(entry.value!==entry.value&&value!==value))return true;entry=entry.next;}return false;}export function run():number{let head:Entry|undefined=undefined;const values:string[]=[];for(let n=0;n<32;n++){const key="common-key-"+n;values.push(key);head={value:key,next:head};}let count=0;for(let i=0;i<1048576;i++){const key=values[i&31];if(key!==undefined&&has(head,key))count++;}return count===1048576?42:1;}`,
  "branch-context",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 4194304,
    allocationCapacity: 131072,
    rootCapacity: 8192,
    stackBytes: 1048576,
  },
);
