from pathlib import Path
import base64, datetime, gzip, hashlib, json, re, statistics, subprocess

p = Path('.tint-bootstrap/perf')
out = Path('docs/results')
stem = 'native-branch-context-throughput-v1'
assets = out / (stem + '-assets')

def read(name):
    return json.loads((p / name).read_text())

def summary(rows, fields):
    return {key: {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
            for key, values in ((key, [get(row) for row in rows]) for key, get in fields.items())}

def operation(name):
    data = read(name)
    assert len(data['observations']) == 8
    assert all(x['initial']['state'] == 'stopped' and x['final'] == {'state': 'exited', 'exitStatus': 42}
               for x in data['observations'])
    return {'file': name, 'summary': [summary([r for r in data['observations'] if r['index'] == i],
        {k: lambda r, k=k: r[k] for k in ['cpuLowerBoundMs', 'inferiorWallMs', 'instructions', 'cycles']})
        for i in [0, 1]]}

def suite(name):
    data = read(name + '.json')
    assert data['complete'] and data['requestedVariants'] == 9 and data['totals']['passed'] == 9
    journal = [json.loads(line) for line in (p / (name + '.jsonl')).read_text().splitlines()]
    assert journal[-1]['kind'] == 'complete'
    return data

def canonical_cpu(prefix):
    folder = p / prefix
    rows = read(prefix + '/observations.json')
    result = []
    for row in rows:
        cpu = read(prefix + '/' + row['label'] + '-' + str(row['index']) + '/cpu.json')
        result.append({**row, 'variantImageIndex': int(row['command'].split()[-1]), 'cpu': cpu})
    return result

cohorts = [read(name + '/result.json') for name in
           ['selfbuild-branch-context-v4', 'selfbuild-branch-context-reverse-v1', 'selfbuild-branch-context-current-v1']]
for data in cohorts:
    assert data['signatureExit'] == data['dwarfExit'] == 0
    assert data['afterStageImageIdentical'] and data['identicalCompilerOutputs']
    assert all(x['initial']['state'] == 'stopped' and x['final']['state'] == 'exited'
               and x['final']['exitStatus'] == 0 and x['identicalToAfterStage1'] for x in data['observations'])
compiler_summary = []
for group in [cohorts[:2], cohorts[2:]]:
    rows = [row for c in group for row in c['observations']]
    compiler_summary.append({label: summary([r for r in rows if r['label'] == label], {
        'cpuMs': lambda r: r['cpu']['cpuMsLowerBound'], 'wallMs': lambda r: r['inferiorWallMs'],
        'instructions': lambda r: r['cpu']['lastCPU']['instructions'], 'cycles': lambda r: r['cpu']['lastCPU']['cycles']})
        for label in ['before', 'after']})
ops = [operation(name) for name in [
    'branch-context-set-cpu-v4.json', 'branch-context-boolean-cpu-v4.json',
    'branch-context-extra-reference-cpu-v1.json', 'branch-context-extra-number-cpu-v1.json',
    'branch-context-set-current-cpu-v1.json', 'branch-context-boolean-current-cpu-v1.json']]
for name in ['branch-context-semantics-cpu-v4.json', 'branch-context-semantics-current-cpu-v1.json']:
    operation(name)
canonical = [suite('branch-context-' + infix + label + '-equivalence-v1')
             for infix in ['', 'current-'] for label in ['before', 'after']]
for i in [0, 2]:
    a, b = canonical[i:i+2]
    assert a['sourceSnapshot'] == b['sourceSnapshot']
    assert a['variantSubsetSha256'] == b['variantSubsetSha256']
    assert a['executionResources'] == b['executionResources']
    assert [(x['path'], x['sha256'], x['variant'], x['harness'], x['status']) for x in a['observations']] == [
        (x['path'], x['sha256'], x['variant'], x['harness'], x['status']) for x in b['observations']]
final_selfbuild = read('selfbuild-branch-context-final-v88/result.json')
assert final_selfbuild['signatureExit'] == final_selfbuild['dwarfExit'] == 0
assert final_selfbuild['afterStageImageIdentical']
assert final_selfbuild['observations'][0]['final']['exitStatus'] == 0
gate = read('branch-context-final-gate-v2-exit.json')
assert gate['status'] == 0
gate_log = (p / 'branch-context-final-gate-v2.log').read_text()
assert '[tint-check] all gates passed' in gate_log
tests = int(re.findall(r'ℹ tests ([0-9]+)', gate_log)[-1])
snapshot = read('branch-context-final-toolchain-v88/source-snapshot.json')
assert snapshot['identity'] == final_selfbuild['manifest']['sourceSnapshot']
drift = [entry['id'] for entry in snapshot['inputs']
         if Path(entry['id']).read_bytes() != base64.b64decode(entry['bytes'])]
assert not drift, ('Frozen portable source no longer matches current branch', drift)

files = []
for f in p.iterdir():
    if 'branch-context' not in f.name or 'toolchain' in f.name or 'staging' in f.name:
        continue
    if f.is_file(): files.append(f)
    elif f.is_dir(): files.extend(x for x in f.rglob('*') if x.is_file())
for host in ['branch-context-main-toolchain-v80', 'branch-context-toolchain-v82', 'branch-context-control-toolchain-v83',
             'branch-context-current-main-toolchain-v84', 'branch-context-current-toolchain-v86', 'branch-context-current-control-toolchain-v87',
             'branch-context-final-toolchain-v88']:
    files.extend(p / host / name for name in ['toolchain.json', 'source-snapshot.json'])
    files.extend(f for f in (p / host / 'tools').glob('perf*') if f.is_file())
files.extend(p / n for n in ['time-cpu-counters-v1.ts', 'observe-selfbuild-cpu-v2.py', 'record-background-exit-v1.mjs',
                            'leaf-reference-operation-variants-v1.json'])
assets.mkdir(exist_ok=True)
index = []
for f in sorted(set(files)):
    if f.suffix not in ['.json', '.jsonl', '.ts', '.js', '.mjs', '.py', '.txt', '.log']: continue
    data = f.read_bytes()
    dest = assets / (str(f.relative_to(p)).replace('/', '--') + '.gz')
    dest.write_bytes(gzip.compress(data, mtime=0))
    index.append({'source': str(f), 'asset': str(dest), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
report = {'kind': 'native-direct-logical-condition-throughput', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    'codeHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'change': 'Branch through !, &&, || and transparent groups in condition contexts; retain value-producing logical and nullish paths.',
    'selfbuildCohorts': cohorts, 'selfbuildSummary': compiler_summary, 'operationSummary': ops,
    'finalIntegrationSelfbuild': final_selfbuild,
    'canonical': canonical, 'canonicalCPU': {prefix: canonical_cpu(prefix) for prefix in [
        'observe-branch-context-before-cpu-v1', 'observe-branch-context-after-cpu-v1',
        'observe-branch-context-current-before-cpu-v1', 'observe-branch-context-current-after-cpu-v1']},
    'nativeAttribution': read('branch-context-native-attribution-v1.json'),
    'staticCounts': read('branch-context-static-summary-v1.json'), 'gate': gate, 'gateTests': tests,
    'validationBase': final_selfbuild['manifest'],
    'setupFailures': 'v1 EEXIST and v2 missing input path fail before native entry; v3 exposed a pre-existing unsupported mixed String/Boolean fixture expression. Separate assertions retain the same truthiness cases. Initial selfbuild continuations stopped on these prerequisites before native execution. v4 reuses verified unchanged stage1 bytes with explicit provenance. None is a semantic pass or authorization stall.',
    'projection': 'No whole-suite hour projection from operation loops or three selected heavy inferiors. Node-hosted per-batch compilation does not execute the changed native output. Historical journal-only compilation estimates are context, not a current execution forecast.',
    'assets': index}
(out / (stem + '.json')).write_text(json.dumps(report, indent=2) + '\n')

lines = ['# Direct branches for logical conditions', '',
    'Condition-only `!`, `&&` and `||` now branch directly. The old lowering materialized Boolean intermediate values and join slots before branching again. Value-producing logical expressions, nullish coalescing, evaluation order and abrupt completion retain their existing behavior.', '',
    '| Native workload | Before CPU median (range), ms | After CPU median (range), ms | Instructions change | Cycles change |',
    '| --- | ---: | ---: | ---: | ---: |']
names = ['String membership, first cohort', 'Boolean loop, first cohort', 'Reference membership, first cohort',
         'Number/NaN membership, first cohort', 'String membership, current cohort', 'Boolean loop, current cohort']
for name, op in zip(names, ops):
    a, b = op['summary']
    def cpu(x):
        v = x['cpuLowerBoundMs']; return f"{v['median']:.3f} ({v['min']:.3f}–{v['max']:.3f})"
    lines.append(f"| {name}, four alternating pairs | {cpu(a)} | {cpu(b)} | {100*(b['instructions']['median']/a['instructions']['median']-1):+.2f}% | {100*(b['cycles']['median']/a['cycles']['median']-1):+.2f}% |")
lines += ['', '**CPU results are mixed:** reference membership regresses, and the current string case has nearly flat cycles despite fewer instructions. All 64 operation/semantic inferiors stop initially and exit 42. Every repetition retains load, wall time and the final missing-CPU bound.', '',
    '| Full native compiler | Before CPU seconds | After CPU seconds | Instructions change | Cycles change |',
    '| --- | ---: | ---: | ---: | ---: |']
for name, group in zip(['First cohort, two execution orders (medians)', 'Current cohort including A1 Script hashes, one pair'], compiler_summary):
    a, b = group['before'], group['after']
    lines.append(f"| {name} | {a['cpuMs']['median']/1000:.3f} | {b['cpuMs']['median']/1000:.3f} | {100*(b['instructions']['median']/a['instructions']['median']-1):+.2f}% | {100*(b['cycles']['median']/a['cycles']['median']-1):+.2f}% |")
lines += ['', 'The first-cohort individual CPU pairs are 237.997→238.084 s and 276.474→238.110 s: the first is flat and baseline spread is wide. The current pair is a separate source graph; no cross-source performance ratio is used. CPU is inferior user+system, not debugger or Node time. Static matched `hasSet` bodies shrink 159→153, 141→126 and 146→131 instructions; the latter two also remove six pointer/float carrier moves. Calls and field loads are unchanged.', '',
    'All six native compiler executions exit 0 and reproduce their candidate stage-1 image byte for byte. The four first-cohort outputs are 52,457,634 bytes, SHA-256 `e3c2451b35d858d02eb41bcb625ef013be58da0e2ad337efe02c7573be41171a`; both current outputs have the same size and SHA-256 `ee589fd28dacf68f5fdf87d755cc590dd4ce3d2feaca900356a5555f3e76b5c2`. Signing and DWARF checks pass. Selfbuilds use `selfbuild-perf 1`, suites use one shared runner, and short fixtures use LLDB directly.', '',
    f'Both source cohorts pass the identical **9/9 before and 9/9 after** pinned Test262 selection. Sources, harness hashes, strictness/goals, resources, fresh process isolation, 300 s containment and terminal complete journals are preserved. The fresh rebased workspace gate passes **{tests:,} tests**, types, dependency boundaries and formatting. These overlapping performance selections add no coverage denominator.', '',
    f"After main added IR initialization-proof pruning, a separate final correctness-only selfbuild uses source `{snapshot['identity']['sha256']}` on main `{final_selfbuild['manifest']['mainCommit']}`. Its native compiler exits 0 and reproduces stage 1, SHA-256 `{final_selfbuild['observations'][0]['outputSha256']}`. Signing and DWARF checks pass. Earlier timings and Test262 outcomes retain their own source identities; no cross-source ratio or later-graph conformance count is invented.", '',
    'The retained setup failures are pre-entry observations: an existing output filename, a missing input filename and a baseline-unsupported mixed-carrier fixture assertion. The corrected native fixture checks ordering, skipped operands, exceptions/finally, loop control, nullish values, NaN, negative zero and truthiness on both generated representations. Six red-first lowering tests compare condition contexts with equivalent nested branches; value-returning logical expressions retain their carriers.', '',
    f'[Raw evidence]({stem}.json) includes every load/counter observation, current-source equivalence, frozen manifests/source snapshots, control adapters, stage-image checks, setup failures and hash-indexed assets. The [native hot-function table](native-hot-functions-v16.md) separates expected graph work from per-operation overhead. No whole-suite hours reduction is projected from these samples; Node-hosted batch compilation is a separate path.', '']
lines += ['| Current-cohort native variant | Before CPU seconds | After CPU seconds | Instructions change | Cycles change |',
          '| --- | ---: | ---: | ---: | ---: |']
cpu_rows = {label: {row['variantImageIndex']: row for row in report['canonicalCPU']['observe-branch-context-current-'+label+'-cpu-v1']}
            for label in ['before','after']}
for case, name in [(0, 'Addition A1 sloppy'), (1, 'Addition A1 strict'), (4, 'Call A1 sloppy')]:
    a, b = [cpu_rows[label][case]['cpu'] for label in ['before','after']]
    lines.append(f"| {name}, one matched pair | {a['cpuMsLowerBound']/1000:.3f} | {b['cpuMsLowerBound']/1000:.3f} | {100*(b['lastCPU']['instructions']/a['lastCPU']['instructions']-1):+.2f}% | {100*(b['lastCPU']['cycles']/a['lastCPU']['cycles']-1):+.2f}% |")
lines += ['', 'These single canonical CPU pairs are not medians. Their load averages, lifetime counters and final missing-CPU bounds are retained per variant. Instructions/cycles and CPU are reported independently; a CPU regression is not hidden by an instruction reduction.', '']
(out / (stem + '.md')).write_text('\n'.join(lines))
for row in index:
    data = gzip.decompress(Path(row['asset']).read_bytes())
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print({'report': stem, 'assets': len(index), 'gateTests': tests})
