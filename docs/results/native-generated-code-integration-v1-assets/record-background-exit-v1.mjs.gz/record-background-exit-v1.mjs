import{spawnSync}from'node:child_process';import{writeFileSync}from'node:fs';
const [report,command,...args]=process.argv.slice(2),startedUTC=new Date().toISOString(),r=spawnSync(command,args,{stdio:'inherit'});
writeFileSync(report,JSON.stringify({startedUTC,endedUTC:new Date().toISOString(),command,args,status:r.status,signal:r.signal,error:r.error?.message},null,2)+'\n',{flag:'wx'});process.exitCode=r.status??1;
