from pathlib import Path
import json,gzip,hashlib,statistics,datetime,subprocess,shutil
p=Path('.tint-bootstrap/perf');out=Path('docs/results');stem='native-generated-code-integration-v1';assets=out/(stem+'-assets');assets.mkdir(exist_ok=True)
def read(n):return json.loads((p/n).read_text())
reports={label:read(f'integrated-perf-{label}-equivalence-v1.json')for label in ['before','after']}
assert all(r['complete']and r['totals']['passed']==9 and sum(r['totals'][k]for k in ['failed','unsupported','timeouts','harnessErrors','crashes'])==0 for r in reports.values())
identity=lambda r:[(o['path'],o['variant'],o['sha256'],o['harness'],o['status'])for o in r['observations']]
assert identity(reports['before'])==identity(reports['after'])
assert reports['before']['sourceSnapshot']==reports['after']['sourceSnapshot']
assert reports['before']['executionResources']==reports['after']['executionResources']
selfbuild=read('integrated-perf-selfbuild-v3/result.json');assert selfbuild['afterStageImageIdentical']and selfbuild['identicalCompilerOutputs']and selfbuild['signatureExit']==0 and selfbuild['dwarfExit']==0
assert all(o['initial']['state']=='stopped'and o['final']['state']=='exited'and o['final']['exitStatus']==0 and o['identicalToAfterStage1']for o in selfbuild['observations'])
gate=read('integrated-perf-gate-v1-exit.json');assert gate['status']==0
fixture=read('integrated-string-fixture-cpu-v1.json');assert len(fixture['observations'])==8 and all(o['initial']['state']=='stopped'and o['final']['state']=='exited'and o['final']['exitStatus']==42 for o in fixture['observations'])
cpus={}
for label in ['before','after']:
 root=f'observe-integrated-perf-{label}-cpu-v1';cpus[label]=[]
 for o in read(root+'/observations.json'):
  case=int(o['command'].rsplit(' ',1)[1]);f=p/root/(label+'-'+str(o['index']))/'cpu.json'
  cpus[label].append({'case':case,'path':reports[label]['observations'][case]['path'],'variant':reports[label]['observations'][case]['variant'],'discovery':o,'cpu':json.loads(f.read_text())if f.exists()else None})
for label in ['before','after']:
 assert all(next(x for x in cpus[label]if x['case']==case)['cpu']is not None for case in [0,1,4])
files=[]
for pat in ['integrated-perf-*','integrated-string-*','integrated-main-v74-*','rebuild-integrated-main-*','profile-integrated-perf-*','observe-integrated-perf-*']:
 for f in p.glob(pat):
  if 'toolchain'in f.name or'staging'in f.name or'selfbuild-reverse'in f.name:continue
  if f.is_file():files.append(f)
  elif f.is_dir():files.extend(v for v in f.rglob('*')if v.is_file())
for tc in ['integrated-perf-main-toolchain-v70','integrated-perf-toolchain-v72','integrated-perf-control-toolchain-v73','integrated-perf-rebuilt-main-toolchain-v74']:
 files.extend(p/tc/n for n in ['toolchain.json','source-snapshot.json'])
control=read('integrated-perf-control-v73.json');files.append(Path(control['adapter']));files.extend(Path(control['host']['directory'])/'tools'/e['file']for e in control['files'])
files.extend(p/n for n in ['retain-integrated-perf-v1.py','record-background-exit-v1.mjs','time-cpu-counters-v1.ts','observe-selfbuild-cpu-v2.py','p_capture_report_v1.py'])
index=[]
for f in sorted(set(files)):
 if not f.exists()or f.suffix not in ['.json','.jsonl','.ts','.js','.mjs','.py','.txt','.log']or any('staging'in x for x in f.parts):continue
 b=f.read_bytes();dst=assets/(str(f.resolve().relative_to(p.resolve())).replace('/','--')+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));index.append({'source':str(f),'asset':str(dst),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r={'kind':'native-generated-code-current-main-integration','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Both stacked slices in the same merge range: bounded reference-helper inlining plus four-unit UTF16 machine-code kernels. Unchanged pinned Test262 JS/harness, fresh process, strictness/goal, resources, timeout, classifier, journal and resume semantics.','inputs':read('integrated-perf-v75-manifest.json'),'baselineControl':control,'sharedBuiltJSProof':read('integrated-perf-dist-equivalence-v1.json'),'fullBaselineCompilerIdentity':read('integrated-perf-selfbuild-v3/control-identity.json'),'selfbuild':selfbuild,'strongStringFixture':fixture,'strongFixtureBuilds':read('integrated-string-fixture-builds-v1.json'),'canonical':{k:{'totals':v['totals'],'sourceSnapshot':v['sourceSnapshot'],'frozenToolchainSha256':v['frozenToolchainSha256'],'compilation':v['compilation'],'resources':v['executionResources']}for k,v in reports.items()},'canonicalCPU':cpus,'gate':gate,'gateCodeProvenance':read('integrated-perf-gate-v1-code-provenance.json'),'status':'Correctness complete; combined reverse-order CPU cohort pending. Not READY.','fullGateTests':4880,'nativeCompilerSamples':read('integrated-perf-native-attribution-v1.json'),'preEntryFailures':[{'attempt':'integrated-perf-selfbuild-v1','reason':'Baseline70 captured stale main dist. Full baseline control compiler-image identity failed before native launch.'},{'attempt':'integrated-perf-selfbuild-v2','reason':'Preflight did not publish required manifest after finding an unreferenced obsolete candidate-only dist file. Driver failed before native launch; corrected v3 independently proves full compiler-byte identity.'}],'cancelledDiagnostics':[{'name':'profile-integrated-perf-addition-v1','reason':'Release images lack function names; unresolved baseline samples retained, unstarted candidate sampling cancelled. Canonical runner uninterrupted.'},{'name':'profile-integrated-perf-selfbuild-v1/v2','reason':'Initial-stop waiters cancelled after pre-entry upstream failures; no native execution interrupted.'}],'projection':'Selected CPU/native operation gains do not justify a whole-suite hours projection. Historical all-journal v19 compile-only estimate143.478h is Node-hosted and not a prediction for this code.','assets':index}
(out/(stem+'.json')).write_text(json.dumps(r,indent=2)+'\n')
for label in ['before','after']:
 for ext in ['json','jsonl']:shutil.copyfile(p/f'integrated-perf-{label}-equivalence-v1.{ext}',out/f'test262-perf-generated-code-{label}-v1.{ext}')
lines=[]
for case in [0,1,4]:
 vals=[next(x for x in cpus[label]if x['case']==case)for label in ['before','after']];a,b=[x['cpu']for x in vals];lines.append(f"| {vals[0]['path'].split('/')[-2]} {vals[0]['variant']} | {a['cpuMsLowerBound']/1000:.3f} / {b['cpuMsLowerBound']/1000:.3f} | {100*(b['lastCPU']['instructions']/a['lastCPU']['instructions']-1):+.3f}% | {100*(b['lastCPU']['cycles']/a['lastCPU']['cycles']-1):+.3f}% | {vals[0]['discovery']['load'][0]:.2f} / {vals[1]['discovery']['load'][0]:.2f} |")
a,b=selfbuild['observations'];assert a['label']=='before'and b['label']=='after'
(out/(stem+'.md')).write_text(f'''# Current-main generated-code integration

This report validates **both** stacked performance slices on current portable
main code: [bounded reference-helper inlining](native-reference-inlining-throughput-v1.md)
and [four-unit UTF-16 kernels](native-string-word-kernels-throughput-v1.md).
Their isolated repeated measurements remain separate. The first combined native
compiler CPU pair regresses; a reverse-order pair remains pending, so this
stack is not yet marked READY. Both canonical selections
pass **9/9 with identical outcomes**, unchanged pinned sources/harnesses,
strictness/goals, fresh processes, resources, 300 s containment and journal schema.

| Same-source canonical case, one observation per side | Before / after inferior CPU s | Instructions change | Cycles change | Start load before / after |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(lines)+f'''

These are individual canonical observations, not repeated medians. CPU is
inferior user+system lifetime usage via Darwin V4 counters; the raw report retains
last-unobserved wall bounds, load and missing fast-process observations as null.
`observation.elapsedMs` includes shared preparation/queueing and is not execution
wall time. Full canonical JSON and terminal journals are separate immutable files.
The Node-hosted nine-variant compile wall times are
{reports['before']['compilation']['batches'][0]['compileMs']/1000:.3f} /
{reports['after']['compilation']['batches'][0]['compileMs']/1000:.3f} s per batch,
or {reports['before']['compilation']['batches'][0]['compileMs']/9000:.3f} /
{reports['after']['compilation']['batches'][0]['compileMs']/9000:.3f} s per variant.
No matched Node compiler CPU or whole-suite hour improvement is claimed.

The fresh native compiler comparison uses exactly the same sealed 601-file
candidate source. Before / after inferior CPU are
{a['cpu']['cpuMsLowerBound']/1000:.3f} / {b['cpu']['cpuMsLowerBound']/1000:.3f} s;
wall {a['inferiorWallMs']/1000:.3f} / {b['inferiorWallMs']/1000:.3f} s. Both exit 0
and reproduce the candidate stage-1 image byte for byte:
{b['outputBytes']:,} bytes, SHA-256 `{b['outputSha256']}`.
Signature and DWARF verification pass. One pair verifies current-main integration;
isolated reports provide the two-order compiler repetitions for each slice.
The strengthened string fixture passes eight LLDB initial-stop/exit-42 checks,
including original-unit verification and allocation churn. The full worktree
`tint-check` passes **4,880 tests**, types, dependency boundaries and formatting.
Main changes after its code base are docs-only; the gate covers the merged code.

The first integration attempt caught stale built `dist` files in the main
checkout before native execution. A fresh offline install/build from archived
main `{r['inputs']['mainCommit']}` in local staging repaired the baseline without
writing main. Its built JavaScript equals the sealed control's three replacements
apart from one unreferenced obsolete candidate-only file. More decisively, the
complete freshly rebuilt main compiler image equals the same-source control
image byte for byte. Baseline70 is retained as a failed preparation observation;
it supplies no performance/equivalence result. A second missing-manifest
preflight attempt also failed before native entry. The corrected v3 is explicit.

[Raw evidence]({stem}.json) includes frozen identities, all counters, logs,
source manifests, control adapters, exact-image proof, native compiler samples
and the failed pre-entry observations as hash-indexed compressed assets.
Release canonical samples lacked function names and are retained as unresolved,
not assigned invented percentages. New symbolized compiler windows are reported
in [native hot functions v15](native-hot-functions-v15.md); their phase-dependent
shares are not per-function speedup ratios. No whole-suite forecast is extrapolated
from a nine-case selection or operation microbenchmarks.
''')
print({'report':stem,'assets':len(index)})
