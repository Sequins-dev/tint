function region(base:number,length:number):(address:number)=>boolean {
 return (address:number):boolean=>address>=base&&address-base<=length-8;
}
export function run():number {
 const contains=region(100,65536);let present=0;
 for(let i=0;i<3000000;i++)if(contains(100+(i%65536)))present++;
 return present===2999685?42:1;
}
