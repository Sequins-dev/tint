import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-deferred-roots-toolchain-v39/tools/hosted-fixture.ts";
verifyHostedFixture(
  `function churn():void{for(let i=0;i<3000;i++){const bytes=new Uint32Array(64);bytes[0]=i;}}function scan(value:unknown,count:number,collect:boolean):number{let total=0;for(let i=0;i<count;i++){if(value===42)total++;else if(value===undefined)total+=2;else total+=3;}if(collect)churn();return total;}export function run():number{return scan(42,50000000,false)===50000000?42:1;}`,
  "deferred-roots-allocation",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 524288,
    allocationCapacity: 32768,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
