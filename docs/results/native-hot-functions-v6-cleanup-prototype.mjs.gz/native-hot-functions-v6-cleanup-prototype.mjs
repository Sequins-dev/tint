import {registerHooks} from 'node:module';
import {appendFileSync} from 'node:fs';
registerHooks({load(url,context,next){const r=next(url,context);if(!url.endsWith('/packages/ir/dist/optimization/index.js'))return r;let source=String(r.source),pattern='export function optimizeModule(';if(!source.includes(pattern))throw Error('optimizer entry missing');source=source.replace(pattern,'function pOriginalOptimizeModule(');
source+=`
export function optimizeModule(module,maxInstructions=20000000,options={}) {
 if(!Number.isSafeInteger(maxInstructions)||maxInstructions<0)return pOriginalOptimizeModule(module,maxInstructions,options);
 let instructions=0,blocks=0,slots=0;
 for(const fn of module.functions){slots+=fn.slots.length;blocks+=fn.blocks.length;for(const b of fn.blocks)instructions+=b.instructions.length;}
 if(instructions*5+slots*2+blocks<=maxInstructions)return pOriginalOptimizeModule(module,maxInstructions,options);
 const functions=[],effects=summarizeEffects(module);let visited=0,forwarded=0,stores=0,dead=0,compacted=0,skipped=0;
 for(const fn of module.functions){
  if(fn.import===true){functions.push(fn);continue;}
  let current=fn,spent=0;const limit=Math.min(50000,maxInstructions-visited);
  if(limit<=0){functions.push(fn);skipped++;continue;}
  const f=forwardLocalLoads(current,limit,effects);
  if(f===undefined){visited+=limit;functions.push(current);skipped++;continue;}
  current=f.fn;spent+=f.visited;forwarded+=f.forwarded;
  const s=removeUnreadStores(current,limit-spent);
  if(s===undefined){visited+=limit;functions.push(current);skipped++;continue;}
  current=s.fn;spent+=s.visited;stores+=s.removed;
  const d=removeDeadScalars(current,limit-spent);
  if(d===undefined){visited+=limit;functions.push(current);skipped++;continue;}
  current=d.fn;spent+=d.visited;dead+=d.removed;
  const c=compactSlots(current,limit-spent);
  if(c===undefined){visited+=limit;functions.push(current);skipped++;continue;}
  current=c.fn;spent+=c.visited;compacted+=c.removed;visited+=spent;functions.push(current);
 }
 const stats={phase:'scalar',pass:'function-local-cleanup',visited,rewritten:forwarded+stores+dead+compacted,skipped};
 if(process.env.TINT_P_LOCAL_CLEANUP_LOG)globalThis.__pCleanupLog?.({instructions,blocks,slots,...stats,forwarded,stores,dead,compacted});
 return {module:{...module,functions},passes:[stats],budgetExhausted:skipped>0};
}
`;
return {...r,source};}});
globalThis.__pCleanupLog=x=>appendFileSync(process.env.TINT_P_LOCAL_CLEANUP_LOG,JSON.stringify(x)+'\n');
