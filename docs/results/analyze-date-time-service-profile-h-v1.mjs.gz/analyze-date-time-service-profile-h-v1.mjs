import{readFileSync,writeFileSync}from'node:fs';
const[file,out]=process.argv.slice(2);if(!out)throw Error('profile output required');
const p=JSON.parse(readFileSync(file)),nodes=new Map(p.nodes.map(n=>[n.id,n])),parent=new Map();for(const n of p.nodes)for(const c of n.children??[])parent.set(c,n.id);
const self=new Map(),inclusive=new Map();let total=0;
for(let i=0;i<(p.samples??[]).length;i++){const id=p.samples[i],us=p.timeDeltas?.[i]??0;total+=us;self.set(id,(self.get(id)??0)+us);let at=id;while(at!==undefined){inclusive.set(at,(inclusive.get(at)??0)+us);at=parent.get(at);}}
const rank=counts=>[...counts].sort((a,b)=>b[1]-a[1]).slice(0,40).map(([id,us])=>{const n=nodes.get(id);return{id,seconds:us/1e6,percent:us*100/total,function:n.callFrame.functionName,url:n.callFrame.url,line:n.callFrame.lineNumber+1};});
const report={kind:'v8-native-service-compile-profile',conformance:false,profile:file,samplingSeconds:total/1e6,self:rank(self),inclusive:rank(inclusive),scope:'Diagnostic profiled build; exclude its CPU measurements from acceptance comparisons.'};writeFileSync(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({self:report.self.slice(0,15),inclusive:report.inclusive.slice(0,15)},null,2));
