import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// Stack overflow must surface as a catchable RangeError (never a fault), repeatedly, with recovery.
const expectRange = (label: string, body: string) => `try { ${body}; throw new Error("${label}: no overflow"); } catch (e) { if (!(e instanceof RangeError)) throw new Error("${label}: " + e); }`;
const sources = [
  `function f(n) { return f(n + 1) + 1; }
   for (var i = 0; i < 3; i++) { ${expectRange("recursion", "f(0)")} }
   function g(n) { return n === 0 ? 0 : g(n - 1) + 1; }
   if (g(500) !== 500) throw new Error("recovery");`,
  `var a = []; for (var i = 0; i < 30000; i++) a = [a]; ${expectRange("json", "JSON.stringify(a)")} ${expectRange("json-again", "JSON.stringify(a)")}`,
  `var a = []; for (var i = 0; i < 30000; i++) a = [a]; var n = 0; while (Array.isArray(a)) { a = a[0]; n++; } if (n !== 30001) throw new Error("depth " + n);`,
  `var o = { get x() { return this.x + 1; } }; ${expectRange("getter", "o.x")}`,
  `var p = new Proxy({}, { get: function (t, k, r) { return r[k]; } }); ${expectRange("proxy", "p.x")}`,
  // 5: a JavaScript throw undefined with no overflow is caught as undefined.
  `var seen = "none"; try { throw undefined; } catch (e) { seen = e === undefined ? "undefined" : String(e); } if (seen !== "undefined") throw new Error("plain: " + seen);`,
  // 6: after a recovered overflow, throw undefined is still caught as undefined.
  `function f(n) { return f(n + 1) + 1; } ${expectRange("first", "f(0)")}
   var seen = "none"; try { throw undefined; } catch (e) { seen = e === undefined ? "undefined" : String(e); } if (seen !== "undefined") throw new Error("after recovery: " + seen);`,
  // 7: IteratorClose swallows an overflow in return() (the throw completion wins): the
  // original undefined reaches the catch, and later throws of undefined stay undefined.
  `function deep(n) { return deep(n + 1) + 1; } var closed = 0;
   var it = { [Symbol.iterator]: function () { return { next: function () { return { value: 1, done: false }; }, return: function () { closed++; deep(0); } }; } };
   var seen = "none"; try { for (var x of it) throw undefined; } catch (e) { seen = e === undefined ? "undefined" : String(e); }
   if (closed !== 1 || seen !== "undefined") throw new Error("close: " + closed + " " + seen);
   seen = "none"; try { throw undefined; } catch (e) { seen = e === undefined ? "undefined" : String(e); } if (seen !== "undefined") throw new Error("after close: " + seen);`,
  // 8: an unrelated catch inside finally while the overflow unwinds does not turn it into undefined.
  `function g() { try { g(); } finally { try { throw 1; } catch (e) {} } }
   var seen = "none"; try { g(); } catch (e) { seen = e instanceof RangeError ? "range" : String(e); } if (seen !== "range") throw new Error("finally: " + seen);`,
  // 9: a runtime-internal catch (IteratorClose on a throw completion swallows the
  // overflow raised by return(), and the loop body's value wins) followed by ordinary
  // JavaScript throws:
  // each later value reaches its catch unchanged, and the next overflow is a RangeError.
  `function deep(n) { return deep(n + 1) + 1; }
   var it = { [Symbol.iterator]: function () { return { next: function () { return { value: 1, done: false }; }, return: function () { deep(0); } }; } };
   var marker = { tag: "ordinary" }, seen = "none";
   try { for (var x of it) throw marker; } catch (e) { seen = e === marker ? "marker" : String(e); }
   if (seen !== "marker") throw new Error("swallow: " + seen);
   seen = "none"; try { throw 7; } catch (e) { seen = e === 7 ? "seven" : String(e); } if (seen !== "seven") throw new Error("number: " + seen);
   seen = "none"; try { null.x; } catch (e) { seen = e instanceof TypeError ? "type" : String(e); } if (seen !== "type") throw new Error("type: " + seen);
   seen = "none"; try { throw undefined; } catch (e) { seen = e === undefined ? "undefined" : String(e); } if (seen !== "undefined") throw new Error("undefined: " + seen);
   ${expectRange("next overflow", "deep(0)")}`,
];
const cases = sources.map((source) => { const plan = executionPlan(source, "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(process.argv[2]!, built.bytes); chmodSync(process.argv[2]!, 0o755);
console.error(new Date().toISOString(), "wrote", process.argv[2], built.bytes.length);
