import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// Scaled shapes of staging/sm/regress/regress-610026.js (sequential empty blocks)
// and regress-563221.js (unresolved references in a never-called function).
// Exit 42 = the eval completed; 10 = unsupported; anything else = failure.
const blocks = (k: number) => `var s = "{}"; for (var i = 0; i < ${k}; i++) s += s; eval(s);`;
const others = (n: number) => `"" + eval("(function () { if (x) ; else if (y) n(); else { " + Array(${n}).join("e;") + " } });");`;
const specs = (process.argv[3] ?? "b16,b18,b20,b21,e1000,e2000,e5000,e10000").split(",");
const literal = (k: number) => `eval("${"{}".repeat(2 ** k)}");`;
const strings = (k: number) => `var s = "1;"; for (var i = 0; i < ${k}; i++) s += s; eval(s);`;
const full = `var s = "{}"; for (var i = 0; i < 21; i++) s += s; eval(s); s += s.slice(0, -4); eval(s); s += "{}"; eval(s);`;
const isolate: Record<string, string> = {
  n16: `var s = "{}"; for (var i = 0; i < 16; i++) s += s; if (s.length !== 131072) throw 1;`,
  w17: `eval(" ".repeat(131072));`,
  c17: `eval("/*" + "x".repeat(131068) + "*/");`,
  r16: `eval("{}".repeat(65536));`,
  r15: `eval("{}".repeat(32768));`,
  p16: `var s = "{}"; for (var i = 0; i < 16; i++) s += s; eval(s.slice(0));`,
  semi70k: `eval(";".repeat(70000));`,
  semi140k: `eval(";".repeat(140000));`,
  blk40k: `eval("{}".repeat(40000));`,
  blk3_40k: `eval("{;}".repeat(40000));`,
  nest: `eval("{".repeat(100) + "}".repeat(100));`,
  live32r15: `var big = "x".repeat(2 ** 24) + "y"; eval("{}".repeat(32768)); if (big.length !== 2 ** 24 + 1) throw 1;`,
  live64r15: `var big = "x".repeat(2 ** 24) + "y", big2 = "z".repeat(2 ** 24) + "w"; eval("{}".repeat(32768)); if (big.length + big2.length < 0) throw 1;`,
  live64semi: `var big = "x".repeat(2 ** 24) + "y", big2 = "z".repeat(2 ** 24) + "w"; eval(";".repeat(65536)); if (big.length + big2.length < 0) throw 1;`,
};
const sources = specs.map((spec) => { const n = Number(spec.slice(1)); return isolate[spec] !== undefined ? isolate[spec]! : spec === "full" ? full : spec[0] === "b" ? blocks(n) : spec[0] === "l" ? literal(n) : spec[0] === "s" ? strings(n) : others(n); });
const out = process.argv[2]!;
const cases = sources.map((source) => { const plan = executionPlan(source, "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(out, built.bytes); chmodSync(out, 0o755);
console.error(new Date().toISOString(), "wrote", out, specs.join(","), built.bytes.length);
