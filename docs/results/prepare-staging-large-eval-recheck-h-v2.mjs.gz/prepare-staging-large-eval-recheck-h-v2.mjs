import {writeFileSync} from 'node:fs';
import {test262Checkout,test262Source} from '../tools/test262-checkout.ts';
import {testMetadata,syntaxVariants} from '../tools/test262.ts';
const want=new Set(['staging/sm/class/compPropNames.js','staging/sm/class/methDefn.js','staging/sm/regress/regress-610026.js','staging/sm/regress/regress-563221.js']),rows=[];
for(const dir of ['staging/sm/class','staging/sm/regress']){const suite=test262Checkout('.tint-bootstrap/test262',dir);if(suite.dirty||suite.revision!=='91c70759363c46557b694792bf34a2551a7af5ba')throw Error('pinned checkout mismatch');for(const file of suite.files){if(!want.has(file.path))continue;const {source,sha256}=test262Source(file.filename);for(const variant of syntaxVariants(testMetadata(source)))rows.push({path:file.path,variant,sha256});}}
rows.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:a.variant<b.variant?-1:1);
writeFileSync('docs/results/staging-large-eval-recheck-variants-h-v2.json',JSON.stringify(rows,null,2)+'\n',{flag:'wx'});console.log(rows.length, rows.map(r=>r.path.split('/').pop()+':'+r.variant).join(' '));
