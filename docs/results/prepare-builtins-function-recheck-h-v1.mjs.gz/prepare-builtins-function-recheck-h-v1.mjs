import {readFileSync,writeFileSync} from 'node:fs';
import {test262Checkout,test262Source} from '../tools/test262-checkout.ts';
import {testMetadata,syntaxVariants} from '../tools/test262.ts';
const checkout='.tint-bootstrap/test262',suite=test262Checkout(checkout,'built-ins/Function');
if(suite.dirty||suite.revision!=='91c70759363c46557b694792bf34a2551a7af5ba')throw Error('pinned checkout mismatch');
const all=new Map();for(const file of suite.files){const {source,sha256}=test262Source(file.filename);for(const variant of syntaxVariants(testMetadata(source)))all.set(file.path+'\0'+variant,{path:file.path,variant,sha256});}
if(all.size!==893)throw Error('expected 893 variants, got '+all.size);
const cls=JSON.parse(readFileSync('docs/results/modules-a3-extended-gap-classification-v1.json')).groups.find(g=>g.root==='built-ins/Function');
const rows=Object.values(cls.causes).flat().map(x=>{const v=all.get(x.path+'\0'+x.variant);if(!v)throw Error('unknown variant '+x.path);return v;});
rows.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:a.variant<b.variant?-1:1);
if(new Set(rows.map(r=>r.path+'\0'+r.variant)).size!==167)throw Error('expected 167 distinct');
writeFileSync('docs/results/builtins-function-nonpass-recheck-variants-h-v1.json',JSON.stringify(rows,null,2)+'\n',{flag:'wx'});console.log(rows.length);
