import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-comparison-branches-candidate-toolchain-v44/tools/hosted-fixture.ts";
verifyHostedFixture(
  `import {createList,writeList,readList} from "@tint/foundation/collections/sparse-list"; export function run():number{const list=createList<number>(32);for(let i=0;i<32;i++)writeList<number>(list,i,i);let total=0;for(let i=0;i<16000000;i++){const value=readList<number>(list,i&31);if(value===undefined)return 1;total+=value;}return total===248000000?42:2;}`,
  "comparison-branches-sparse-list",
  [["@tint/foundation/collections/sparse-list","packages/foundation/src/collections/sparse-list.ts"]],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 524288,
    allocationCapacity: 32768,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
