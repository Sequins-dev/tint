import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const [unitPath,monoPath,manifestPath,outPath]=process.argv.slice(2);
if(!outPath)throw Error('unit monolithic manifest output required');
const load=p=>JSON.parse(readFileSync(p)),sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const unit=load(unitPath),mono=load(monoPath),manifest=load(manifestPath);
for(const key of ['revision','sourceSnapshot','frozenToolchainSha256','engine','executionResources','debuggerLaunch'])if(!isDeepStrictEqual(unit[key],mono[key]))throw Error('identity mismatch '+key);
if(unit.nativeLinkingMode!=='aot-native-services-v1'||mono.nativeLinkingMode!=='monolithic'||!unit.nativeServiceUnitIndexSha256||mono.nativeServiceUnitIndexSha256!==null)throw Error('linking identity mismatch');
if(unit.selection!=='intl402/DateTimeFormat'||mono.rootSelection!==unit.selection||mono.requestedVariants!==64||mono.complete!==true)throw Error('selection identity mismatch');
if(unit.totals.total!==490||unit.observations.length!==490||mono.totals.total!==64||mono.observations.length!==64||manifest.length!==64)throw Error('incomplete denominator');
const key=o=>o.path+'#'+o.variant,byKey=rows=>{const map=new Map(rows.map(o=>[key(o),o]));if(map.size!==rows.length)throw Error('duplicate variant');return map;};
const units=byKey(unit.observations),monos=byKey(mono.observations),requested=byKey(manifest);
const normalize=({elapsedMs,batch,...observation})=>observation;
const differences=[];
for(const [id,input] of requested){const a=units.get(id),b=monos.get(id);if(!a||!b||a.sha256!==input.sha256||b.sha256!==input.sha256)throw Error('input mismatch '+id);if(!isDeepStrictEqual(normalize(a),normalize(b)))differences.push({unit:a,monolithic:b});}
for(const path of [unitPath,monoPath])if(JSON.parse(readFileSync(path.replace(/\.json$/,'.jsonl'),'utf8').trim().split('\n').at(-1)).kind!=='complete')throw Error('missing terminal journal '+path);
const report={kind:'native-unit-monolithic-outcome-equivalence',conformance:false,time:new Date().toISOString(),sourceSnapshot:unit.sourceSnapshot,frozenToolchainSha256:unit.frozenToolchainSha256,nativeServiceUnitIndexSha256:unit.nativeServiceUnitIndexSha256,unit:{path:unitPath,sha256:sha(unitPath),totals:unit.totals},monolithic:{path:monoPath,sha256:sha(monoPath),totals:mono.totals},manifest:{path:manifestPath,sha256:sha(manifestPath)},variants:64,compared:'Predeclared32files, both strictness variants. Every input/harness hash, metadata, capability, status and complete outcome; only elapsedMs and batch index omitted. Same frozen toolchain, collector and300s containment. Full linked490 retained; monolithic64 is a complete explicit subset, not a second full-family result.',differences,accepted:differences.length===0};
writeFileSync(outPath,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({variants:64,differences:differences.length}));if(differences.length)process.exitCode=1;
