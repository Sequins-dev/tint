import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {readJournal} from '../tools/test262-coverage-ledger.ts';
const [family,version='1',frozen='137']=process.argv.slice(2);
if(!family)throw Error('family required');
const tag='test262-temporal-'+family.toLowerCase()+'-unmeasured-h-v'+version,base='docs/results/'+tag;
const manifestFile='docs/results/temporal-'+family.toLowerCase()+'-unmeasured-variants-h-v1.json';
const manifest=JSON.parse(readFileSync(manifestFile)),report=JSON.parse(readFileSync(base+'.json'));
const journal=await readJournal(base+'.jsonl'),descriptorFile='docs/results/frozen-node-toolchain-temporal-builtins-h-v'+frozen+'.json',descriptor=JSON.parse(readFileSync(descriptorFile));
const key=x=>x.path+'\0'+x.variant,expected=new Map(manifest.map(x=>[key(x),x]));
if(!journal.complete||!report.complete||report.rootSelection!=='built-ins/Temporal/'+family||report.requestedVariants!==manifest.length||report.observations.length!==manifest.length||journal.observations.length!==manifest.length)throw Error('incomplete selection');
for(const rows of [report.observations,journal.observations]){const seen=new Set();for(const row of rows){const wanted=expected.get(key(row));if(!wanted||wanted.sha256!==row.sha256||seen.has(key(row)))throw Error('manifest row mismatch');seen.add(key(row));}if(seen.size!==expected.size)throw Error('manifest denominator mismatch');}
if(!isDeepStrictEqual(report.sourceSnapshot,descriptor.sourceSnapshot)||!isDeepStrictEqual(journal.header.sourceSnapshot,descriptor.sourceSnapshot))throw Error('source provenance mismatch');
if(report.engine.debuggerLaunch!=='debugserver-direct'||report.nativeLinkingMode!=='monolithic'||report.executionResources.timeoutMs!==300000)throw Error('run policy mismatch');
if(!isDeepStrictEqual(report.totals,journal.totals))throw Error('journal totals mismatch');
const sha=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const proof={kind:'builtin-temporal-breadth-measurement-acceptance',conformance:false,time:new Date().toISOString(),selection:report.rootSelection,inventory:'temporal-builtins-unmeasured-selection-index-h-v1.json',implementationOnMain:'22ca7b65c84cb205d5abb664b6b18c92145a74a7',scope:'Complete explicit subset of every remaining v18 unmeasured variant in this family. Prior passing reports retain their separate provenance; no live prefix or Node observation is counted.',report:tag+'.json',journal:tag+'.jsonl',manifest:manifestFile.split('/').at(-1),manifestSha256:sha(manifestFile),requestedVariants:manifest.length,terminalComplete:true,exactManifestMembershipVerified:true,totals:report.totals,sourceSnapshot:report.sourceSnapshot,frozenToolchain:descriptorFile.split('/').at(-1),frozenToolchainSha256:report.frozenToolchainSha256,debuggerLaunch:report.engine.debuggerLaunch,nativeLinkingMode:report.nativeLinkingMode,timeoutMs:report.executionResources.timeoutMs,reportSha256:sha(base+'.json'),journalSha256:sha(base+'.jsonl'),nonPasses:report.observations.filter(x=>x.status!=='pass').map(x=>({path:x.path,variant:x.variant,status:x.status,detail:x.detail}))};
writeFileSync('docs/results/temporal-'+family.toLowerCase()+'-unmeasured-acceptance-h-v'+version+'.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({selection:proof.selection,totals:proof.totals}));
