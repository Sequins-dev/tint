#!/bin/zsh
# Alternating stage1 self-compiles: main (v169) vs parser window (v4), counters via proc_pid_rusage.
W=/Users/stephenbelanger/.t3/worktrees/tint/t3-8512c14e/.tint-bootstrap
SP=/private/tmp/claude-501/-Users-stephenbelanger-Code-nodejs-tint/a98254cc-5091-45e8-a1f5-cb6d1358715d/scratchpad
OUT=$W/selfbuild-bench-h-v1; mkdir -p $OUT
for pair in 1 2; do
  for tag in stack-guard-h-v169 parser-window-h-v4; do
    rm -f $OUT/pid $OUT/stage2-$tag
    python3 $SP/rusage-poll.py $OUT/pid $OUT/$tag-$pair.json &
    poller=$!
    start=$(date +%s)
    zsh -c "echo \$\$ > $OUT/pid; exec $W/stage1-$tag $W/source-$tag $OUT/stage2-$tag --debug-symbols" > $OUT/$tag-$pair.log 2>&1
    code=$?
    wait $poller
    echo "$(date -u +%H:%M:%S) pair=$pair $tag exit=$code wall=$(( $(date +%s) - start ))s $(cat $OUT/$tag-$pair.json)" >> $OUT/summary.txt
  done
done
echo DONE >> $OUT/summary.txt
