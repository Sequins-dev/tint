import { spawnSync, spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { tmpdir, loadavg } from 'node:os';
import { createHash } from 'node:crypto';
import { readWorkspaceSourceSnapshot } from '../../tools/workspace-sources.ts';
import { startNativeHeartbeat } from '../../tools/test262-native-heartbeat.ts';
import { debugserverLaunchCommand } from '../../tools/native-debugger-session.ts';
const directory = resolve('.tint-bootstrap/perf/selfbuild-ordered-inline-reverse-v1');
mkdirSync(directory);
const manifest = JSON.parse(readFileSync('.tint-bootstrap/perf/ordered-inline-candidate-v64-manifest.json','utf8'));
const prerequisite = JSON.parse(readFileSync('.tint-bootstrap/perf/selfbuild-inline-unions-post-C2-v1/result.json','utf8'));
if (!prerequisite.identical || prerequisite.final.exitStatus !== 0) throw Error('post-C2 baseline has not validated');
const source = manifest.sourceRoot, frozen = manifest.baseToolchain.directory;
const snapshot = readWorkspaceSourceSnapshot(manifest.sourceSnapshotFile);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

for(const input of snapshot.inputs) if(!Buffer.from(input.bytes).equals(readFileSync(source+'/'+input.id))) throw Error('source changed '+input.id);
const toolchain = JSON.parse(readFileSync(frozen+'/toolchain.json','utf8'));
for(const file of toolchain.files) if(digest(readFileSync(frozen+'/'+file.path)) !== file.sha256) throw Error('frozen file changed '+file.path);
const heartbeat = startNativeHeartbeat('P matched bounded reference-helper inlining');
const before = directory+'/before-stage1', after = directory+'/after-stage1';
writeFileSync(directory+'/inputs.json',JSON.stringify({manifest,loadStart:loadavg(),compilerHosts:[manifest.baseToolchain,manifest.afterToolchain],scope:'Both executable compiler workloads use identical candidate TypeScript sources. Their generated output must match the after stage1 image byte for byte. The after compiler must also reproduce its own stage image. Each host emits directly from the same sealed TypeScript source input.'},null,2)+'\n');
try {
 heartbeat.phase('reuse hash-checked stage1 images from the successful first cohort');
 const priorDirectory=resolve('.tint-bootstrap/perf/selfbuild-ordered-inline-v1'),prior=JSON.parse(readFileSync(priorDirectory+'/result.json','utf8'));
 if(!prior.afterStageImageIdentical||!prior.identicalCompilerOutputs||prior.observations.length!==2)throw Error('First cohort incomplete');
 for(const [label,target]of[['before',before],['after',after]]){const bytes=readFileSync(priorDirectory+'/'+label+'-stage1');writeFileSync(target,bytes,{mode:0o755,flag:'wx'});if(!readFileSync(target).equals(bytes))throw Error('copy mismatch');}
 writeFileSync(directory+'/stage1-provenance.json',JSON.stringify({reusedFrom:priorDirectory,sourceSnapshot:manifest.sourceSnapshot,beforeSha256:digest(readFileSync(before)),afterSha256:digest(readFileSync(after)),scope:'Exact signed debug stage1 images from the successful matched first cohort, copied byte for byte. Fresh native compiler process per observation.'},null,2)+'\n',{flag:'wx'});
 heartbeat.phase('waiting for paired integer-bank native checks'); while(!existsSync('.tint-bootstrap/perf/ordered-inline-native-checks-v1-exit.json')){console.error('P self-build awaiting native fixture/counter completion '+new Date().toISOString());await new Promise(r=>setTimeout(r,30000));} if(JSON.parse(readFileSync('.tint-bootstrap/perf/ordered-inline-native-checks-v1-exit.json','utf8')).status!==0)throw Error('Paired native checks failed');
 const expected=readFileSync(after), observations=[];
 for(const [label,image] of [['after',after],['before',before]]) {
  const run=directory+'/'+label;mkdirSync(run);
  process.env.TINT_P_REPORT_CAPTURE=run+'/reports.jsonl';
  heartbeat.phase(label+' native compiler under LLDB');
  const session=mkdtempSync(join(tmpdir(),'tint-p-dense-self-'));
  const initial=run+'/initial.json',final=run+'/final.json',output=run+'/stage2';
  const commands=['settings set target.disable-aslr false',
   'command script import '+resolve('.tint-bootstrap/perf/p_capture_report_v1.py'),
   'script bp=lldb.debugger.GetSelectedTarget().BreakpointCreateByRegex("program:packages/compiler/src/cli.ts:report "); assert bp.GetNumLocations()>0; bp.SetScriptCallbackFunction("p_capture_report_v1.capture")',
   debugserverLaunchCommand(image,session,[source,output,'--debug-symbols'],300000,'direct'),
   `script import json,time; p=lldb.debugger.GetSelectedTarget().GetProcess(); open(${JSON.stringify(initial)},'w').write(json.dumps({'state':'stopped' if p.GetState()==lldb.eStateStopped else str(p.GetState()),'pid':p.GetProcessID(),'monotonicNs':time.monotonic_ns()})); assert p.GetState()==lldb.eStateStopped`,
   'continue',
   `script import json,time; p=lldb.debugger.GetSelectedTarget().GetProcess(); open(${JSON.stringify(final)},'w').write(json.dumps({'state':'exited' if p.GetState()==lldb.eStateExited else str(p.GetState()),'exitStatus':p.GetExitStatus(),'monotonicNs':time.monotonic_ns()})); p.Kill() if p.GetState()!=lldb.eStateExited else None`];
  const observer=spawn('python3',[resolve('.tint-bootstrap/perf/observe-selfbuild-cpu-v2.py'),run],{stdio:'inherit'});
  const observed=new Promise((resolve,reject)=>observer.once('close',status=>status===0?resolve(undefined):reject(Error('CPU observer '+status))));
  const loadBefore=loadavg();
  const r=spawnSync('/usr/bin/lldb',['--no-lldbinit','--batch',...commands.flatMap(c=>['-o',c]),image],{stdio:'inherit'});
  if(!existsSync(initial))observer.kill('SIGTERM');
  await observed;
  const start=JSON.parse(readFileSync(initial,'utf8')),end=JSON.parse(readFileSync(final,'utf8'));
  if(r.status!==0||start.state!=='stopped'||end.state!=='exited'||end.exitStatus!==0)throw Error(label+' native compiler failed '+JSON.stringify(end));
  const bytes=readFileSync(output);
  if(!bytes.equals(expected))throw Error(label+' output differs from after stage1');
  const observation={label,initial:start,final:end,loadBefore,loadAfter:loadavg(),cpu:JSON.parse(readFileSync(run+'/cpu.json','utf8')),inferiorWallMs:(end.monotonicNs-start.monotonicNs)/1000000,outputSha256:digest(bytes),outputBytes:bytes.length,identicalToAfterStage1:true};
  observations.push(observation);writeFileSync(run+'/result.json',JSON.stringify(observation,null,2)+'\n');
 }
 heartbeat.phase('verifying final compiler signature and DWARF');
 const signature=spawnSync('codesign',['--verify','--strict',after],{stdio:'inherit'}),dwarf=spawnSync('dwarfdump',['--verify',after],{stdio:'inherit'});
 if(signature.status!==0||dwarf.status!==0)throw Error('signature or DWARF validation failed');
 writeFileSync(directory+'/result.json',JSON.stringify({manifest,observations,signatureExit:signature.status,dwarfExit:dwarf.status,afterStageImageIdentical:true,identicalCompilerOutputs:true,cpuSpeedup:observations.find(o=>o.label==='before').cpu.cpuMsLowerBound/observations.find(o=>o.label==='after').cpu.cpuMsLowerBound,scope:'One full native compiler execution per generated representation; same exact TypeScript source and identical emitted compiler bytes. Operation benchmarks provide repeated CPU medians. Both stage-1 hosts are frozen production implementations. Workspace and native fixture gates remain required.'},null,2)+'\n');
}finally{heartbeat.close();}
