import lldb,json

def capture(debugger,command,result,internal_dict):
 t=debugger.GetSelectedTarget();rows=[]
 for s in t.GetModuleAtIndex(0):
  name=s.GetName()or''
  if not name.startswith(('program:','runtime:')):continue
  a=s.GetStartAddress().GetFileAddress();b=s.GetEndAddress().GetFileAddress()
  if b<=a:continue
  rows.append({'name':name,'start':a,'bytes':b-a,'instructions':(b-a)//4})
 with open(command.strip(),'x')as f:json.dump(rows,f);f.write('\n')
 print('function sizes',len(rows))
def __lldb_init_module(debugger,internal_dict):debugger.HandleCommand('command script add -f list_native_function_sizes_v1.capture p-sizes')
