import lldb,json

def capture(debugger,command,result,internal_dict):
 t=debugger.GetSelectedTarget();rows=[]
 for s in t.GetModuleAtIndex(0):
  name=s.GetName()or''
  if ':readList ['not in name:continue
  a=s.GetStartAddress().GetFileAddress();b=s.GetEndAddress().GetFileAddress();body=t.ReadInstructions(s.GetStartAddress(),(b-a)//4);calls=[]
  for i in body:
   if i.GetMnemonic(t)in['bl','blr']:calls.append({'offset':i.GetAddress().GetFileAddress()-a,'op':i.GetMnemonic(t),'operands':i.GetOperands(t),'comment':i.GetComment(t)})
  rows.append({'name':name,'instructions':len(body),'calls':calls,'loads':sum(i.GetMnemonic(t).startswith(('ldr','ldp','ldur'))for i in body),'stores':sum(i.GetMnemonic(t).startswith(('str','stp','stur'))for i in body)})
  if len(rows)==3:break
 with open(command.strip(),'x')as f:json.dump(rows,f,indent=2);f.write('\n')
 print(json.dumps(rows))
def __lldb_init_module(debugger,internal_dict):debugger.HandleCommand('command script add -f read_list_calls_v1.capture p-calls')
