import { parseScript } from "@tint/typescript/syntax";
import { createSourceTextView } from "@tint/source/text";
import { prepareManagedSurfaceEntry, declareManagedJitRuntime } from "@tint/compiler/native";
import { lowerScript } from "../packages/js-engine/src/lowering/index.ts";
import { createManagedScriptFixture } from "../tools/managed-script-fixture.ts";
// Native Map/Set give every object key hash 0: each operation probes the whole
// collection. Charge object-keyed operations their collection size, by call site.
const fixture = createManagedScriptFixture(), runtime = declareManagedJitRuntime(fixture.runtime);
const costs = new Map<string, number>(); let active = false;
function site(): string { const s = new Error().stack!.split("\n")[4] ?? ""; const m = s.match(/([^/(]+\.(?:ts|js)):(\d+)/); return m ? m[1] + ":" + m[2] : s.trim(); }
function charge(size: number, key: unknown) { if (!active || key === null || (typeof key !== "object" && typeof key !== "function")) return; const k = site(); costs.set(k, (costs.get(k) ?? 0) + size); }
for (const C of [Map, Set] as any[]) for (const m of ["get", "has", "set", "add", "delete"]) { const o = C.prototype[m]; if (!o) continue; C.prototype[m] = function (this: any, key: unknown, ...r: unknown[]) { charge(this.size, key); return o.call(this, key, ...r); }; }
for (const n of (process.argv[2] ?? "250,500").split(",").map(Number)) {
  let code = "({"; for (let i = 0; i < n; i++) code += "['foo' + " + i + "]: 'ok', "; code += "['bar']: 'ok'});";
  const p = parseScript(createSourceTextView(code)); if (!p.ok) throw 1; const l = lowerScript(p.value, code); if (!l.ok) throw 2;
  costs.clear(); active = true; const r = prepareManagedSurfaceEntry({ ...fixture, runtime, module: l.value, entry: "execute" }); active = false; if (!r.ok) throw 3;
  console.log("N=" + n, "total probe cost", [...costs.values()].reduce((a, b) => a + b, 0));
  for (const [k, v] of [...costs].sort((a, b) => b[1] - a[1]).slice(0, 12)) console.log("  ", v, k);
}
