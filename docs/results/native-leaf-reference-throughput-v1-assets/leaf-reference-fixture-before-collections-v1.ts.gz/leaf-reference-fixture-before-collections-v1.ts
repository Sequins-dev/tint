import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-reference-temporary-toolchain-v23/tools/hosted-fixture.ts";

verifyHostedFixture(
  `import {createSet,addSet,hasSet} from "@tint/foundation/collections/linked-set";
import {createList,writeList,readList} from "@tint/foundation/collections/sparse-list";
export function run():number {
 const set=createSet<number>(),list=createList<number>(32);
 for(let i=0;i<32;i++){addSet(set,i);writeList(list,i,i);}
 let count=0;
 for(let i=0;i<4000000;i++)if(hasSet(set,i&31))count++;
 for(let i=0;i<8000000;i++){const value=readList(list,i&31);if(value===undefined)return 1;count+=value;}
 return count===128000000?42:2;
}`,
  "leaf-reference-collections",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 32768,
    allocationCapacity: 4096,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
