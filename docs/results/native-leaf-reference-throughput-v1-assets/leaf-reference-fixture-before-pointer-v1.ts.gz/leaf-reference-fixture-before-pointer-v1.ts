import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-reference-temporary-toolchain-v23/tools/hosted-fixture.ts";

verifyHostedFixture(
  `interface Link { next:Link|undefined; }
function walk(first:Link):Link|undefined {let cursor:Link|undefined=first;for(let i=0;i<50000000;i++){if(cursor===undefined)return undefined;cursor=cursor.next;}return cursor;}
export function run():number {const first:Link={next:undefined},second:Link={next:first};first.next=second;return walk(first)===first?42:1;}`,
  "leaf-reference-walk",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 32768,
    allocationCapacity: 4096,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
