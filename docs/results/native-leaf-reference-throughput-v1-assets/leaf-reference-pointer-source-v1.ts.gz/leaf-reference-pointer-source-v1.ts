interface Link { next:Link|undefined; }
function walk(first:Link):Link|undefined {let cursor:Link|undefined=first;for(let i=0;i<50000000;i++){if(cursor===undefined)return undefined;cursor=cursor.next;}return cursor;}
export function run():number {const first:Link={next:undefined},second:Link={next:first};first.next=second;return walk(first)===first?42:1;}