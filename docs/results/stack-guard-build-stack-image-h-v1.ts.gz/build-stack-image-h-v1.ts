import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// Stack overflow must surface as a catchable RangeError (never a fault), repeatedly, with recovery.
const expectRange = (label: string, body: string) => `try { ${body}; throw new Error("${label}: no overflow"); } catch (e) { if (!(e instanceof RangeError)) throw new Error("${label}: " + e); }`;
const sources = [
  `function f(n) { return f(n + 1) + 1; }
   for (var i = 0; i < 3; i++) { ${expectRange("recursion", "f(0)")} }
   function g(n) { return n === 0 ? 0 : g(n - 1) + 1; }
   if (g(500) !== 500) throw new Error("recovery");`,
  `var a = []; for (var i = 0; i < 30000; i++) a = [a]; ${expectRange("json", "JSON.stringify(a)")} ${expectRange("json-again", "JSON.stringify(a)")}`,
  `var a = []; for (var i = 0; i < 30000; i++) a = [a]; var n = 0; while (Array.isArray(a)) { a = a[0]; n++; } if (n !== 30001) throw new Error("depth " + n);`,
  `var o = { get x() { return this.x + 1; } }; ${expectRange("getter", "o.x")}`,
  `var p = new Proxy({}, { get: function (t, k, r) { return r[k]; } }); ${expectRange("proxy", "p.x")}`,
];
const cases = sources.map((source) => { const plan = executionPlan(source, "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(process.argv[2]!, built.bytes); chmodSync(process.argv[2]!, 0o755);
console.error(new Date().toISOString(), "wrote", process.argv[2], built.bytes.length);
