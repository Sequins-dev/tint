import {readFileSync,writeFileSync} from 'node:fs';
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';
import {loadSourceGraph} from '@tint/typescript/modules';
import {projectMappings,projectRoots} from '@tint/compiler/cli';
const read=v=>JSON.parse(readFileSync('.tint-bootstrap/node-toolchain-temporal-builtins-h-v'+v+'/source-snapshot.json'));
const prior=read(137),current=read(138);
function graph(snapshot){const loaded=loadSourceGraph(snapshot.inputs.map(x=>({...x,bytes:new Uint8Array(Buffer.from(x.bytes,'base64'))})),projectMappings(),projectRoots());if(!loaded.ok)throw Error(JSON.stringify(loaded));return loaded.value;}
const a=graph(prior),b=graph(current),ids=x=>x.map(m=>m.id).sort();
if(!isDeepStrictEqual(ids(a),ids(b)))throw Error('compiler project module set changed');
for(const field of ['mappings','publicEntries'])if(!isDeepStrictEqual(prior[field],current[field]))throw Error('snapshot '+field+' changed');
const oldInputs=new Map(prior.inputs.map(x=>[x.id,x])),newInputs=new Map(current.inputs.map(x=>[x.id,x]));
const differences=ids(b).filter(id=>!isDeepStrictEqual(oldInputs.get(id),newInputs.get(id)));
if(differences.length)throw Error('compiler project sources changed '+JSON.stringify(differences));
const changedUnreachableInputs=current.inputs.filter(x=>!isDeepStrictEqual(oldInputs.get(x.id),x)).map(x=>x.id);
const inputBytes=ids(b).map(id=>newInputs.get(id));
const proof={kind:'full-compiler-project-graph-evidence-reuse',conformance:false,time:new Date().toISOString(),prior:'frozen-node-toolchain-temporal-builtins-h-v137.json',current:'frozen-node-toolchain-temporal-builtins-h-v138.json',priorSourceIdentity:prior.identity,currentSourceIdentity:current.identity,roots:projectRoots(),reachableModules:ids(b),reachableInputRecordsSha256:createHash('sha256').update(JSON.stringify(inputBytes)).digest('hex'),snapshotMappingsAndPublicEntriesIdentical:true,changedReachableInputs:differences,changedUnreachableInputs,selfBuild:'temporal-partial-locale-selfbuild-h-v137.json',reason:'Every actual compiler bootstrap root resolves to the same 222 modules with byte-identical complete input records. Import mappings and public entries are identical. The only changed portable inputs are three RegExp engine modules outside this graph; current runtime integration is validated separately by native regression cases and the workspace gate.'};
writeFileSync('docs/results/temporal-partial-locale-full-compiler-graph-h-v138.json',JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({modules:b.length,differences,changedUnreachableInputs}));
