import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// Scaled shapes of staging/sm/regress/regress-610026.js (sequential empty blocks)
// and regress-563221.js (unresolved references in a never-called function).
// Exit 42 = the eval completed; 10 = unsupported; anything else = failure.
const blocks = (k: number) => `var s = "{}"; for (var i = 0; i < ${k}; i++) s += s; eval(s);`;
const others = (n: number) => `"" + eval("(function () { if (x) ; else if (y) n(); else { " + Array(${n}).join("e;") + " } });");`;
const specs = (process.argv[3] ?? "b16,b18,b20,b21,e1000,e2000,e5000,e10000").split(",");
const sources = specs.map((spec) => spec[0] === "b" ? blocks(Number(spec.slice(1))) : others(Number(spec.slice(1))));
const out = process.argv[2]!;
const cases = sources.map((source) => { const plan = executionPlan(source, "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(out, built.bytes); chmodSync(out, 0o755);
console.error(new Date().toISOString(), "wrote", out, specs.join(","), built.bytes.length);
