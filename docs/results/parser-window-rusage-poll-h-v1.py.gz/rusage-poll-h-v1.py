import ctypes,struct,sys,time,json
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
pidfile,out=sys.argv[1],sys.argv[2]
pid=None
for _ in range(3000):
    try: pid=int(open(pidfile).read().strip()); break
    except Exception: time.sleep(0.05)
buf=ctypes.create_string_buffer(512); last=None
while True:
    if lib.proc_pid_rusage(pid,4,ctypes.byref(buf))!=0: break
    user,system=struct.unpack_from('QQ',buf.raw,16)
    maxfoot,=struct.unpack_from('Q',buf.raw,240); ins,cyc=struct.unpack_from('QQ',buf.raw,248)
    last={'user_ns':user,'system_ns':system,'instructions':ins,'cycles':cyc,'lifetime_max_phys_footprint':maxfoot}
    time.sleep(0.05)
json.dump({'pid':pid,'last':last},open(out,'w'))
