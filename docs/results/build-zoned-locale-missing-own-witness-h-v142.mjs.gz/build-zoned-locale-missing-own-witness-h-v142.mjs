import {resolve} from 'node:path';
import {startNativeHeartbeat} from './node-toolchain-temporal-builtins-h-v142/tools/test262-native-heartbeat.ts';
import {verifyNativeScriptCases} from './node-toolchain-temporal-builtins-h-v142/tools/native-script-fixture.ts';
const h=startNativeHeartbeat('ZonedDateTime missing own locale method native witness');
try{h.phase('compiling unfixed frozen142 witness');process.chdir(resolve('.tint-bootstrap/node-toolchain-temporal-builtins-h-v142'));verifyNativeScriptCases([String.raw`if(Object.getOwnPropertyDescriptor(Temporal.ZonedDateTime.prototype,"toLocaleString")!==undefined)throw 1;const value=Temporal.ZonedDateTime.prototype.toLocaleString.call({toString(){return "generic";}});if(value!=="generic")throw 2;`],{nodeReference:false});}finally{await h.close();}
