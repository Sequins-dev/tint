import { parseScript } from "@tint/typescript/syntax";
import { createSourceTextView } from "@tint/source/text";
import { prepareManagedSurfaceEntry, declareManagedJitRuntime } from "@tint/compiler/native";
import { lowerScript } from "../packages/js-engine/src/lowering/index.ts";
import { createManagedScriptFixture } from "../tools/managed-script-fixture.ts";
const fixture = createManagedScriptFixture(), runtime = declareManagedJitRuntime(fixture.runtime);
const shapes: Record<string, (n: number) => string> = {
  statements: (n) => "(function () { if (x) ; else if (y) n(); else { " + Array(n).join("e;") + " } });",
  blocks: (n) => "{}".repeat(n),
};
const kind = process.argv[2]!;
for (const n of process.argv[3]!.split(",").map(Number)) {
  const text = shapes[kind]!(n);
  let t = performance.now();
  const p = parseScript(createSourceTextView(text)); if (!p.ok) throw new Error("parse " + JSON.stringify(p.error).slice(0, 200));
  const tParse = performance.now() - t; t = performance.now();
  const l = lowerScript(p.value, text); if (!l.ok) { console.log(JSON.stringify({ n, lowerError: JSON.stringify(l.error).slice(0, 200) })); continue; }
  const tLower = performance.now() - t; t = performance.now();
  const r = prepareManagedSurfaceEntry({ ...fixture, runtime, module: l.value, entry: "execute" });
  console.log(JSON.stringify({ kind, n, parseMs: Math.round(tParse), lowerMs: Math.round(tLower), prepareMs: Math.round(performance.now() - t), ok: r.ok, code: r.ok ? r.value.native.code.length : JSON.stringify(r.error).slice(0, 160) }));
}
