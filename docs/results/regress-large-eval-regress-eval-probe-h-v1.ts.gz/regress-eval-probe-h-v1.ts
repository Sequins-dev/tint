import { createSourceTextView } from "@tint/source/text";
import { parseScript } from "@tint/typescript/syntax";
import { lowerDirectEvalScript } from "@tint/js-engine/lowering";
import { prepareManagedSurfaceEntry } from "@tint/compiler/native";
import { createManagedScriptFixture } from "../tools/managed-script-fixture.ts";
// usage: node probe.ts else|blocks n1,n2,...
const fixture = createManagedScriptFixture();
const kind = process.argv[2]!;
for (const n of process.argv[3]!.split(",").map(Number)) {
  const code = kind === "else"
    ? "(function () { if (x) ; else if (y) n(); else { " + Array(n).join("e;") + " } });"
    : "{}".repeat(n);
  const t0 = performance.now();
  const parsed = parseScript(createSourceTextView(code)); if (!parsed.ok) { console.log(JSON.stringify({ n, parse: parsed.error })); continue; }
  const t1 = performance.now();
  const lowered = lowerDirectEvalScript(parsed.value, code, 0, { privateEnvironment: false, fieldInitializer: false }); if (!lowered.ok) { console.log(JSON.stringify({ n, lower: lowered.error })); continue; }
  const t2 = performance.now();
  const prepared = prepareManagedSurfaceEntry({ ...fixture, module: lowered.value, entry: "execute" });
  const t3 = performance.now();
  console.log(JSON.stringify({ kind, n, sourceBytes: code.length, parseMs: +(t1 - t0).toFixed(1), lowerMs: +(t2 - t1).toFixed(1), prepareMs: +(t3 - t2).toFixed(1), ok: prepared.ok, codeBytes: prepared.ok ? prepared.value.native.code.length : undefined, error: prepared.ok ? undefined : JSON.stringify(prepared.error).slice(0, 200) }));
}
