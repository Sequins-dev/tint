import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const [unitPath,monoPath,outPath]=process.argv.slice(2);
if(!outPath)throw Error('unit monolithic output required');
const load=p=>JSON.parse(readFileSync(p));const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const unit=load(unitPath),mono=load(monoPath);
for(const key of ['revision','sourceSnapshot','frozenToolchainSha256','variantPolicy','selection','executionResources'])if(!isDeepStrictEqual(unit[key],mono[key]))throw Error('identity mismatch '+key);
if(unit.nativeLinkingMode!=='aot-native-services-v1'||mono.nativeLinkingMode!=='monolithic'||!unit.nativeServiceUnitIndexSha256||mono.nativeServiceUnitIndexSha256!==null)throw Error('linking mode mismatch');
function normalized(report){if(report.totals.total!==490||report.observations.length!==490)throw Error('incomplete selection');return report.observations.map(({elapsedMs,batch,...o})=>o).sort((a,b)=>(a.path+'#'+a.variant).localeCompare(b.path+'#'+b.variant));}
const a=normalized(unit),b=normalized(mono);if(new Set(a.map(x=>x.path+'#'+x.variant)).size!==490)throw Error('duplicate unit rows');if(new Set(b.map(x=>x.path+'#'+x.variant)).size!==490)throw Error('duplicate monolithic rows');
const differences=a.flatMap((row,i)=>isDeepStrictEqual(row,b[i])?[]:[{unit:row,monolithic:b[i]}]);
for(const path of [unitPath,monoPath]){const last=readFileSync(path.replace(/\.json$/,'.jsonl'),'utf8').trim().split('\n').at(-1);if(JSON.parse(last).kind!=='complete')throw Error('missing complete journal '+path);}
const report={kind:'native-unit-monolithic-outcome-equivalence',conformance:false,time:new Date().toISOString(),sourceSnapshot:unit.sourceSnapshot,frozenToolchainSha256:unit.frozenToolchainSha256,nativeServiceUnitIndexSha256:unit.nativeServiceUnitIndexSha256,unit:{path:unitPath,sha256:sha(unitPath),totals:unit.totals},monolithic:{path:monoPath,sha256:sha(monoPath),totals:mono.totals},variants:490,compared:'Every input/harness hash, variant metadata, suspend capability, status and complete outcome; only measurement elapsedMs and batch index omitted.',differences};writeFileSync(outPath,JSON.stringify(report,null,2)+'\n',{flag:'wx'});if(differences.length)process.exitCode=1;console.log(JSON.stringify({variants:490,differences:differences.length}));
