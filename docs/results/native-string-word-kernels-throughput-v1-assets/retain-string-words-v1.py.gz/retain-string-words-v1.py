from pathlib import Path
import json,gzip,hashlib,statistics,datetime,subprocess
p=Path('.tint-bootstrap/perf');out=Path('docs/results');stem='native-string-word-kernels-throughput-v1';assets=out/(stem+'-assets');assets.mkdir(exist_ok=True)
def read(n):return json.loads((p/n).read_text())
def summary(rows,keys):return {k:{'median':statistics.median(x[k]for x in rows),'min':min(x[k]for x in rows),'max':max(x[k]for x in rows)}for k in keys}
cases={n:read(f'string-words-{n}-cpu-v1.json')for n in ['semantics','short','long','copy']};ops={n:{label:summary([x for x in r['observations']if x['index']==i],['cpuLowerBoundMs','inferiorWallMs','instructions','cycles'])for i,label in enumerate(['before','after'])}for n,r in cases.items()};assert all(len(r['observations'])==8 and all(x['initial']['state']=='stopped'and x['final']=={'state':'exited','exitStatus':42}for x in r['observations'])for r in cases.values())
selfs=[read(n+'/result.json')for n in ['selfbuild-string-words-v1','selfbuild-string-words-reverse-v1']];ss={}
for label in ['before','after']:
 rows=[x for r in selfs for x in r['observations']if x['label']==label];assert len(rows)==2 and all(x['initial']['state']=='stopped'and x['final']['state']=='exited'and x['final']['exitStatus']==0 and x['identicalToAfterStage1']for x in rows)
 values=[{'cpuMs':x['cpu']['cpuMsLowerBound'],'wallMs':x['inferiorWallMs'],'instructions':x['cpu']['lastCPU']['instructions'],'cycles':x['cpu']['lastCPU']['cycles']}for x in rows];ss[label]=summary(values,['cpuMs','wallMs','instructions','cycles'])
files=[]
for pat in ['string-words-*','string-word-case-builds-*','prepare-string-word-*','run-string-word-*','freeze-string-words-*','selfbuild-string-words-*']:
 for f in p.glob(pat):
  if f.is_file():files.append(f)
  elif f.is_dir()and'staging'not in f.name:files.extend(v for v in f.rglob('*')if v.is_file())
for tc in ['codegen-string-words-toolchain-v66','codegen-string-words-toolchain-v68','codegen-string-words-control-toolchain-v69']:
 files.extend(p/tc/n for n in ['toolchain.json','source-snapshot.json'])
control=read('string-words-control-v69.json');files.append(Path(control['adapter']));files.append(Path(control['host']['directory'])/'tools'/'perf-conservative-inline.js')
files.extend(p/n for n in ['retain-string-words-v1.py','disassemble_string_words_v1.py','observe-selfbuild-cpu-v2.py','time-cpu-counters-v1.ts','p_capture_report_v1.py'])
index=[]
for f in sorted(set(files)):
 if not f.exists()or f.suffix not in ['.json','.jsonl','.ts','.js','.mjs','.py','.txt','.log']or any('staging'in x for x in f.parts):continue
 b=f.read_bytes();dst=assets/(str(f.resolve().relative_to(p.resolve())).replace('/','--')+'.gz');dst.write_bytes(gzip.compress(b,mtime=0));index.append({'source':str(f),'asset':str(dst),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r={'kind':'native-string-word-kernels-throughput','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'AArch64 flat UTF16 equality/startsWith/copy machine-code kernels. No string representation, GC permission, allocation, bounds, ABI, Test262 source/harness/timeout/classifier change.','inputs':read('string-words-candidate-v68-manifest.json'),'cases':cases,'operationSummary':ops,'selfbuilds':selfs,'selfbuildSummary':ss,'control':control,'controlMetadataClarification':'Raw v69 filenames/labels were inherited from an inliner-control template. The adapter actually replaces only packages/codegen/dist/aarch64/scalar/strings.js; perf-conservative-inline.js contains the baseline string kernel, as its hash and full-image identity demonstrate.','controlIdentity':read('selfbuild-string-words-v1/control-identity.json'),'static':{k:read(f'string-words-static-{k}-v1.json')for k in ['before','after']},'focusedCodegenTests':313,'currentMainIntegration':'native-generated-code-integration-v1.json','canonicalScope':'The current-main integration report validates both stacked code slices and nine unchanged Test262 variants against a same-source sealed baseline. Isolated operation and compiler measurements here use source68 and only change string code generation relative to source64 host. These cohorts are distinct.','projection':'No defensible whole-suite hour projection from selected operation/native-compiler workloads. Historical all-journal v19 context is 143.478 compilation-only hours at observed occupancy, Node-hosted. These kernels do not execute in the Node-hosted batch compiler.','assets':index}
(out/(stem+'.json')).write_text(json.dumps(r,indent=2)+'\n')
lines=[]
for name in ['short','long','copy']:
 a,b=ops[name]['before'],ops[name]['after'];v=lambda d,k:f"{d[k]['median']:.3f} ({d[k]['min']:.3f}–{d[k]['max']:.3f})"
 lines.append(f"| {name} | {v(a,'cpuLowerBoundMs')} | {v(b,'cpuLowerBoundMs')} | {a['cpuLowerBoundMs']['median']/b['cpuLowerBoundMs']['median']:.3f}x | {100*(1-b['instructions']['median']/a['instructions']['median']):.2f}% | {100*(1-b['cycles']['median']/a['cycles']['median']):.2f}% |")
a,b=ss['before'],ss['after'];(out/(stem+'.md')).write_text('''# Four-unit UTF-16 native kernels

Equality, startsWith, concatenation and slicing process four UTF-16 units per
64-bit load/store while at least four units remain, then use the existing
one-unit tail. The full-word guard prevents overreading even for two-byte-offset
startsWith sources. NUL and lone surrogates remain ordinary code units. Copies
write only into fresh allocations. No allocation or call is added; register
clobbers and destination/count preservation match the existing helper contract.

| Four alternating pairs | Before CPU ms: median (range) | After CPU ms: median (range) | CPU ratio | Fewer instructions | Fewer cycles |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(lines)+f'''

The short workload's cycle median regresses despite its lower CPU median; its
small duration and final unobserved CPU bound prevent claiming a strong short
string win. The long equality workload compares separate 128-unit allocations
2M times; copying does 100K concatenation/slice iterations and verifies content.
[Raw evidence]({stem}.json) retains every CPU/instruction/cycle observation,
wall time, range, load and missing-CPU bound. CPU excludes LLDB launch. All 32
isolated fixture/benchmark inferiors stop initially and exit 42. The stronger
current-main fixture also checks each copied unit against its source and again
after allocation churn; it is retained in the integration report.

The before/after native compiler CPU medians across both execution orders are
{a['cpuMs']['median']/1000:.3f} s ({a['cpuMs']['min']/1000:.3f}–{a['cpuMs']['max']/1000:.3f})
and {b['cpuMs']['median']/1000:.3f} s ({b['cpuMs']['min']/1000:.3f}–{b['cpuMs']['max']/1000:.3f}),
ratio {a['cpuMs']['median']/b['cpuMs']['median']:.3f}x. Retired instructions change
{100*(b['instructions']['median']/a['instructions']['median']-1):+.3f}%; cycle medians change
{100*(b['cycles']['median']/a['cycles']['median']-1):+.3f}%. Frequency/phase effects
remain possible; operation instruction reductions provide independent evidence.
All four native executions exit 0, and stage 2 matches candidate stage 1:
53,745,666 bytes, SHA-256
`7345e5df39459e764fbf6acf0632d89e468674c112b71c9f0bfd748569fa3fae`.
Signature/DWARF checks pass. Source68 is identical for both compilers; sealed
control69 reproduces the complete baseline image byte for byte.

Static disassembly changes the steady equality loop from 32 instructions per
four units to nine, and copying from 24 to seven. Larger static helper bodies
retain scalar tails: equality 24→35 instructions, startsWith 37→48,
slice-copy 18→26, concat-copy 33→49. All remain leaf helpers with zero calls.
The 313 focused codegen tests pass. The fresh full gate, current-main frozen
self-build and canonical nine-case equivalence are recorded separately in the
[current-main integration](native-generated-code-integration-v1.md), which
includes both this code and reference-helper inlining in the same READY range.

No whole-suite speedup or hours saving is extrapolated from these selected
workloads. Batch compilation is Node-hosted; historical journal projections
measure a different path. All raw source/toolchain identities, adapters,
benchmark sources, failed/preparation observations and counters are immutable
compressed assets with an uncompressed SHA-256 index in the JSON report.
''')
print({'report':stem,'assets':len(index),'selfbuild':ss})
