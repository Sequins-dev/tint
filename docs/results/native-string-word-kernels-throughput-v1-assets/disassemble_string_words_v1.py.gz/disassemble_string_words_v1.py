import lldb,json,os

def capture(debugger,command,result,internal_dict):
 target=debugger.GetSelectedTarget();module=target.GetModuleAtIndex(0);rows=[]
 for symbol in module:
  name=symbol.GetName() or ''
  if not any(key in name for key in ['string-equal','string-starts-with','string-concat-copy','string-slice-copy']):continue
  start=symbol.GetStartAddress().GetFileAddress();end=symbol.GetEndAddress().GetFileAddress()
  if end<=start or end-start>100000:continue
  instructions=target.ReadInstructions(symbol.GetStartAddress(),(end-start)//4)
  assert len(instructions)==(end-start)//4
  body=[]
  for index,inst in enumerate(instructions):
   assert inst.GetAddress().GetFileAddress()==start+index*4
   body.append({'offset':index*4,'mnemonic':inst.GetMnemonic(target),'operands':inst.GetOperands(target)})
  counts={'instructions':len(body),'loads':sum(i['mnemonic'].startswith(('ldr','ldp','ldur')) for i in body),'stores':sum(i['mnemonic'].startswith(('str','stp','stur')) for i in body),'calls':sum(i['mnemonic'] in ['bl','blr'] for i in body),'pointerFloatMoves':sum(i['mnemonic']=='fmov' and 'x' in i['operands'] for i in body)}
  rows.append({'function':name,'fileAddress':start,'byteLength':end-start,'counts':counts,'body':body})
 with open(command.strip(),'x') as f:json.dump(rows,f,indent=2);f.write('\n')
 print('captured',len(rows),'native function bodies')

def __lldb_init_module(debugger,internal_dict):debugger.HandleCommand('command script add -f disassemble_string_words_v1.capture p-disassemble')
