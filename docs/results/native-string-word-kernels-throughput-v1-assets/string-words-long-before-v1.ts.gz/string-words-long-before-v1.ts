import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-ordered-inline-toolchain-v64/tools/hosted-fixture.ts";
verifyHostedFixture(
  String.raw`export function run():number{const seed="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";const a=("x"+seed).slice(1),b=("y"+seed).slice(1);let n=0;for(let i=0;i<2000000;i++){if(a===b)n++;}return n===2000000?42:1;}`,
  "string-words",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 1048576,
    allocationCapacity: 65536,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
