import { verifyHostedFixture } from "file:///Users/stephenbelanger/.t3/worktrees/tint/t3-0e68a211/.tint-bootstrap/perf/codegen-runtime-scalar-toolchain-v28/tools/hosted-fixture.ts";

verifyHostedFixture(
  `interface Held { value:number; next:Held|undefined; }
function churn(seed:number,other:number,held:Held):number {
 const first=seed,second=other,third=other+1,fourth=other+2;
 const fifth=other+3,sixth=other+4,seventh=other+5,eighth=other+6;
 let total=0;
 for(let i=0;i<2500;i++){const scratch=new Uint32Array(64);scratch[0]=i;total+=scratch[0]??0;}
 if(total!==3123750||held.value!==42)return 1;
 if(seed!==seed){if(first===first)return 2;}else if(first!==seed||1/first!==1/seed)return 3;
 if(second!==other||third!==other+1||fourth!==other+2||fifth!==other+3||sixth!==other+4||seventh!==other+5||eighth!==other+6)return 4;
 return 42;
}
export function run():number {
 const held:Held={value:42,next:undefined};held.next=held;
 if(churn(-0,1.25,held)!==42||churn(NaN,-17.5,held)!==42||churn(Infinity,23.75,held)!==42||churn(-Infinity,-9.125,held)!==42)return 5;
 return held.next===held&&held.value===42?42:6;
}`,
  "runtime-scalar-registers",
  [],
  [],
  [],
  [],
  {
    runtimeEntry: "initializeCopyingRuntime",
    managedBytes: 32768,
    allocationCapacity: 4096,
    rootCapacity: 4096,
    stackBytes: 1048576,
  },
);
