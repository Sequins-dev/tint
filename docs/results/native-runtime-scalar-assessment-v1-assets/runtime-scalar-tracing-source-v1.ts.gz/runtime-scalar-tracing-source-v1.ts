interface Node { value:number; next:Node|undefined; }
export function run():number {
 let head:Node|undefined=undefined;
 for(let i=0;i<4096;i++)head={value:i,next:head};
 let check=0;
 for(let i=0;i<30000;i++){const scratch=new Uint32Array(64);scratch[0]=i;check+=scratch[0]??0;}
 if(check!==449985000)return 1;
 let count=0,total=0,node=head;
 while(node!==undefined){count++;total+=node.value;node=node.next;}
 return count===4096&&total===8386560?42:2;
}