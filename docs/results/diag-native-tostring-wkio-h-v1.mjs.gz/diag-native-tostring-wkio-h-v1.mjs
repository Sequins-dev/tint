import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {createLoweredRealm} from '../packages/js-engine/test/lowered-node-host.ts';
const h=n=>readFileSync('.tint-bootstrap/test262/harness/'+n,'utf8');
const ctx=vm.createContext({});vm.runInContext(h('wellKnownIntrinsicObjects.js')+';globalThis.__w=WellKnownIntrinsicObjects.map(x=>[x.name,x.source]);',ctx);
const list=JSON.parse(JSON.stringify(ctx.__w)).filter(([,s])=>s);
const skip=new Set(process.argv.slice(2));
const visits=list.filter(([n])=>!skip.has(n)).map(([n,s])=>`try{ var __v=(${s}); }catch(e){ __v=undefined; } if(__v!==undefined){ print('ROOT ${n}'); visit(__v, ${JSON.stringify(n)}); }`).join('\n');
const body=`var visited=[];var bad=0;
function visit(ns,path){ if(visited.indexOf(ns)!==-1)return; visited.push(ns);
 if(typeof ns==='function'){ print('F '+path); var s=Function.prototype.toString.call(ns); try{ validateNativeFunctionSource(s); }catch(e){ bad++; print('BAD '+path+' => '+JSON.stringify(s)); } }
 if(typeof ns!=='function'&&(typeof ns!=='object'||ns===null))return;
 var d=Object.getOwnPropertyDescriptors(ns);
 Reflect.ownKeys(d).forEach(function(k){var x=d[k];var p=typeof k==='symbol'?path+'[Symbol('+k.description+')]':path+'.'+k; if('value' in x)visit(x.value,p); else {visit(x.get,p+'<get>');visit(x.set,p+'<set>');}});}
${visits}
print('visited '+visited.length+' bad '+bad);`;
const realm=createLoweredRealm();
const out=realm.run(h('assert.js')+'\n'+h('sta.js')+'\n'+h('nativeFunctionMatcher.js')+'\n'+body);
console.log('result',out);const p=realm.printed;for(const l of p.filter(l=>!l.startsWith('F ')&&!l.startsWith('ROOT ')))console.log(l);console.log('last:',p.filter(l=>l.startsWith('F ')||l.startsWith('ROOT ')).slice(-2));
