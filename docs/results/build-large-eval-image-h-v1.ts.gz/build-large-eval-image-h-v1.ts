import assert from "node:assert/strict";
import { writeFileSync, chmodSync } from "node:fs";
import { workspaceSources } from "../tools/workspace-sources.ts";
import { createNativeBatchBuilder, prepareNativeScripts } from "../tools/test262-native.ts";
import { executionPlan } from "../tools/test262-execution.ts";
// case k: eval of an object literal with SIZES[k] computed properties ('foo'+i keys).
const sizes = (process.argv[3] ?? "1000,10,100,250,500").split(",").map(Number);
const out = process.argv[2]!;
const pre = `function check(c, m) { if (!c) throw new Error(m); }\n`;
const src = (n: number) => `var code = "({"; for (var i = 0; i < ${n}; i++) code += "['foo' + " + i + "]: 'ok', "; code += "['bar']: 'ok'});"; var obj = eval(code); check(obj.foo${n - 1} === 'ok' && obj.bar === 'ok', 'eval${n}');`;
const cases = sizes.map((n) => { const plan = executionPlan(pre + src(n), "raw", { flags: ["raw"], features: [], includes: [] }); const p = prepareNativeScripts(plan, "raw", []); assert.ok(p.ok, JSON.stringify(p)); return { scripts: p.modules, asynchronous: plan.asynchronous }; });
const t = Date.now(); console.error(new Date().toISOString(), "building", sizes.join(","), "debugSymbols", process.env.TINT_DEBUG_SYMBOLS);
const built = createNativeBatchBuilder(workspaceSources())(cases);
if (!built.ok) assert.fail(JSON.stringify(built.outcome).slice(0, 3000));
writeFileSync(out, built.bytes); chmodSync(out, 0o755);
console.error(new Date().toISOString(), "wrote", out, built.bytes.length, "bytes in", Date.now() - t, "ms");
