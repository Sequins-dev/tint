import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {readJournal} from '../tools/test262-coverage-ledger.ts';
import {readWorkspaceSourceSnapshot,workspaceSourceIdentity} from '../tools/workspace-sources.ts';
// usage: node accept-manifest-report-h-v1.mjs <tag> <manifest.json> <frozen descriptor file name> <selection> <output.json>
const [tag,manifestPath,descriptorFile,selection,output]=process.argv.slice(2),prefix='docs/results/';
if(!output)throw Error('tag manifest descriptor selection output required');
const manifest=JSON.parse(readFileSync(manifestPath)),report=JSON.parse(readFileSync(prefix+tag+'.json')),journal=await readJournal(prefix+tag+'.jsonl'),descriptor=JSON.parse(readFileSync(prefix+descriptorFile)),source=readWorkspaceSourceSnapshot(descriptor.sources),key=x=>x.path+'\0'+x.variant,expected=new Map(manifest.map(x=>[key(x),x]));
if(!journal.complete||!report.complete||report.rootSelection!==selection||report.requestedVariants!==manifest.length||report.observations.length!==manifest.length||journal.observations.length!==manifest.length)throw Error('incomplete selection');
for(const rows of [report.observations,journal.observations]){const seen=new Set();for(const row of rows){const wanted=expected.get(key(row));if(!wanted||wanted.sha256!==row.sha256||seen.has(key(row)))throw Error('manifest mismatch');seen.add(key(row));}if(seen.size!==expected.size)throw Error('denominator mismatch');}
if(!isDeepStrictEqual(report.sourceSnapshot,descriptor.sourceSnapshot)||!isDeepStrictEqual(report.sourceSnapshot,workspaceSourceIdentity(source))||!isDeepStrictEqual(report.totals,journal.totals)||report.frozenToolchainSha256!==journal.header.frozenToolchainSha256)throw Error('provenance mismatch');
if(report.engine.debuggerLaunch!=='debugserver-direct'||report.executionResources.timeoutMs!==300000)throw Error('run policy mismatch');
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const proof={kind:'manifest-report-integrity-validation',conformance:false,time:new Date().toISOString(),report:tag+'.json',journal:tag+'.jsonl',manifest:manifestPath,manifestSha256:hash(manifestPath),reportSha256:hash(prefix+tag+'.json'),journalSha256:hash(prefix+tag+'.jsonl'),terminalComplete:true,exactManifestMembershipVerified:true,requestedVariants:manifest.length,totals:report.totals,frozenToolchain:descriptorFile,sourceSnapshot:report.sourceSnapshot,frozenToolchainSha256:report.frozenToolchainSha256,debuggerLaunch:report.engine.debuggerLaunch,timeoutMs:report.executionResources.timeoutMs,nonPasses:report.observations.filter(x=>x.status!=='pass').map(x=>({path:x.path,variant:x.variant,status:x.status,outcomeKind:x.outcome.kind}))};
writeFileSync(prefix+output,JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({totals:proof.totals,nonPasses:proof.nonPasses.length}));
