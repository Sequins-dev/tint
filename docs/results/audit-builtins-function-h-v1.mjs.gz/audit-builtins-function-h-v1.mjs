import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {test262Checkout,test262Source} from '../tools/test262-checkout.ts';
import {testMetadata,syntaxVariants} from '../tools/test262.ts';
import {executionPlan} from '../tools/test262-execution.ts';
import {readJournal,aggregateEvidence} from '../tools/test262-coverage-ledger.ts';
const checkout='.tint-bootstrap/test262',root='built-ins/Function',expected=new Map(),harnessHashes=new Map();
const suite=test262Checkout(checkout,root);if(suite.dirty||suite.revision!=='91c70759363c46557b694792bf34a2551a7af5ba')throw Error('pinned checkout mismatch');
for(const file of suite.files){const {source,sha256}=test262Source(file.filename),metadata=testMetadata(source);for(const variant of syntaxVariants(metadata)){const plan=executionPlan(source,variant,metadata),harness=plan.harness.map(name=>{if(!harnessHashes.has(name))harnessHashes.set(name,test262Source(resolve(checkout,'harness',name)).sha256);return{name,sha256:harnessHashes.get(name)};});expected.set(file.path+'\0'+variant,{path:file.path,sha256,variant,metadata,harness,canSuspend:plan.canSuspend});}}
const [baseLedger,...mine]=process.argv.slice(2);const base=JSON.parse(readFileSync(baseLedger)),reports=[],used=[];
const load=async(record)=>{const data=record.file.endsWith('.jsonl')?await readJournal(record.file):JSON.parse(readFileSync(record.file));return{...data,...record,totals:data.totals,observations:data.observations.filter(x=>expected.has(x.path+'\0'+x.variant))};};
for(const record of base.reports){const sel=record.rootSelection??record.selection;if(!(sel===root||sel.startsWith(root+'/')||root.startsWith(sel+'/')||sel==='.'||sel==='built-ins'))continue;const r=await load(record);if(!r.observations.length)continue;reports.push(r);used.push(record.file);}
const now=Date.now();mine.forEach((file,i)=>{});for(const [i,file] of mine.entries()){const data=JSON.parse(readFileSync(file));reports.push({...data,file,date:new Date(now+i*1000).toISOString(),selection:data.rootSelection,observations:data.observations,totals:data.totals});used.push(file);}
const result=aggregateEvidence(expected,reports),statuses={};for(const row of result.ledger)statuses[row.status]=(statuses[row.status]??0)+1;
const out={kind:'built-ins-function-ledger-aggregation-audit',conformance:false,time:new Date().toISOString(),baseLedger,expected:expected.size,covered:result.ledger.length,statuses,reports:used,rejected:result.rejected,nonPasses:result.ledger.filter(r=>r.status!=='pass').map(r=>({path:r.path,variant:r.variant,status:r.status}))};
console.log(JSON.stringify({expected:out.expected,covered:out.covered,statuses,rejected:out.rejected.length,nonPasses:out.nonPasses.slice(0,5)}));
if(process.env.AUDIT_OUT)writeFileSync(process.env.AUDIT_OUT,JSON.stringify(out,null,2)+'\n',{flag:'wx'});
