#!/bin/zsh
rm -rf bench-ab; mkdir -p bench-ab
for r in 1 2 3 4 5 6 7 8; do
  for v in base guard; do
    /usr/bin/lldb --batch -o run -o "process status" bench-$v/runtime-native > bench-ab/$v-$r.log 2>&1
  done
done
echo done
